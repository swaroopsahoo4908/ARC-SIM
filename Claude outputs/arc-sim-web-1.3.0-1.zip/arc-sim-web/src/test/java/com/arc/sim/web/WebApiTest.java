package com.arc.sim.web;

import com.arc.sim.MiniJson;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/** End-to-end: starts the real server on a free port and drives it over HTTP. */
class WebApiTest {
    private static WebServer server;
    private static HttpClient http;
    private static String base;

    @BeforeAll
    static void start() throws Exception {
        System.setProperty("PORT", "0");
        System.setProperty("ARC_SIM_THREADS", "2");
        System.setProperty("ARC_MAX_SIMS_PER_JOB", "60");
        server = WebServer.start(Config.fromEnv());
        http = HttpClient.newHttpClient();
        base = "http://127.0.0.1:" + server.port();
    }

    @AfterAll
    static void stop() {
        server.stop();
        System.clearProperty("PORT");
        System.clearProperty("ARC_SIM_THREADS");
        System.clearProperty("ARC_MAX_SIMS_PER_JOB");
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> call(String method, String path, String body, int expectStatus) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(base + path));
        if (body == null) b.method(method, HttpRequest.BodyPublishers.noBody());
        else b.method(method, HttpRequest.BodyPublishers.ofString(body));
        HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
        assertEquals(expectStatus, r.statusCode(), r.body());
        return (Map<String, Object>) MiniJson.parse(r.body());
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> runJob(String json) throws Exception {
        Map<String, Object> created = call("POST", "/api/jobs", json, 202);
        String id = (String) created.get("id");
        for (int i = 0; i < 600; i++) {
            Map<String, Object> s = call("GET", "/api/jobs/" + id, null, 200);
            String state = (String) s.get("state");
            if (state.equals("done")) return (Map<String, Object>) s.get("result");
            assertNotEquals("failed", state, String.valueOf(s.get("error")));
            Thread.sleep(200);
        }
        fail("job did not finish");
        return null;
    }

    private static HttpResponse<byte[]> getBytes(String path) throws Exception {
        return http.send(HttpRequest.newBuilder(URI.create(base + path)).GET().build(),
                HttpResponse.BodyHandlers.ofByteArray());
    }

    private static int triangleCount(byte[] body, boolean gz) throws Exception {
        byte[] raw = body;
        if (gz) raw = new java.util.zip.GZIPInputStream(new java.io.ByteArrayInputStream(body)).readAllBytes();
        int n = java.nio.ByteBuffer.wrap(raw, 0, 4).order(java.nio.ByteOrder.LITTLE_ENDIAN).getInt();
        assertEquals(4 + n * 36 + n, raw.length, "layout: uint32 count, 9 float32 per triangle, 1 class byte per triangle");
        return n;
    }

    @Test
    void demoIsTheCadTemplateAndServesCadMesh() throws Exception {
        List<?> rockets = (List<?>) call("GET", "/api/rockets", null, 200).get("rockets");
        Map<?, ?> demo = (Map<?, ?>) rockets.get(0);
        assertEquals("ARC V2 (CAD template, PLA Basic, 306 g)", demo.get("label"));
        assertEquals(Boolean.TRUE, demo.get("cadAvailable"));
        // Java's HttpClient does not unzip, so the raw body is the gzip stream we sent.
        HttpResponse<byte[]> r = getBytes("/api/rockets/demo/mesh?source=cad");
        assertEquals(200, r.statusCode());
        assertEquals("cad", r.headers().firstValue("X-Mesh-Source").orElse(""));
        assertEquals("gzip", r.headers().firstValue("Content-Encoding").orElse(""));
        assertTrue(triangleCount(r.body(), true) > 40_000, "CAD mesh should be dense");
        HttpResponse<byte[]> g = getBytes("/api/rockets/demo/mesh?source=generated");
        assertEquals("generated", g.headers().firstValue("X-Mesh-Source").orElse(""));
        assertTrue(triangleCount(g.body(), true) < 20_000);
    }

    @Test
    void plaAeroTemplateIsListedLighterAndServesCadMesh() throws Exception {
        List<?> rockets = (List<?>) call("GET", "/api/rockets", null, 200).get("rockets");
        Map<?, ?> basic = null, aero = null;
        for (Object o : rockets) {
            Map<?, ?> m = (Map<?, ?>) o;
            if ("demo".equals(m.get("id"))) basic = m;
            if ("demo-aero".equals(m.get("id"))) aero = m;
        }
        assertNotNull(aero, "PLA Aero template is bundled");
        assertEquals(Boolean.TRUE, aero.get("cadAvailable"));
        double apBasic = ((Number) basic.get("baselineApogeeM")).doubleValue();
        double apAero = ((Number) aero.get("baselineApogeeM")).doubleValue();
        assertTrue(apAero > apBasic + 20, "lighter airframe should fly higher: " + apAero + " vs " + apBasic);
        HttpResponse<byte[]> r = getBytes("/api/rockets/demo-aero/mesh?source=cad");
        assertEquals("cad", r.headers().firstValue("X-Mesh-Source").orElse(""));
    }

    @Test
    void otherRocketsFallBackToGeneratedMesh() throws Exception {
        List<?> rockets = (List<?>) call("GET", "/api/rockets", null, 200).get("rockets");
        Map<?, ?> legacy = null;
        for (Object o : rockets) if ("mod1e".equals(((Map<?, ?>) o).get("id"))) legacy = (Map<?, ?>) o;
        assertNotNull(legacy, "the earlier MOD1E design stays available");
        assertEquals(Boolean.FALSE, legacy.get("cadAvailable"));
        assertNotNull(legacy.get("cadNote"));
        HttpResponse<byte[]> r = getBytes("/api/rockets/mod1e/mesh?source=cad");
        assertEquals("generated", r.headers().firstValue("X-Mesh-Source").orElse(""));
        assertTrue(r.headers().firstValue("X-Mesh-Note").orElse("").contains("not used"));
        triangleCount(r.body(), true);
        assertEquals(404, getBytes("/api/rockets/nope/mesh").statusCode());
    }

    @Test
    void healthAndConfig() throws Exception {
        assertEquals("ok", call("GET", "/api/health", null, 200).get("status"));
        Map<String, Object> cfg = call("GET", "/api/config", null, 200);
        assertEquals(5, ((List<?>) cfg.get("params")).size());
        assertEquals(60.0, (Double) cfg.get("maxSimsPerJob"), 0);
    }

    @Test
    void demoRocketIsListed() throws Exception {
        List<?> rockets = (List<?>) call("GET", "/api/rockets", null, 200).get("rockets");
        assertFalse(rockets.isEmpty());
        Map<?, ?> demo = (Map<?, ?>) rockets.get(0);
        assertEquals("demo", demo.get("id"));
        assertTrue(((Double) demo.get("baselineApogeeM")) > 100);
    }

    @Test
    void sameSeedGivesIdenticalFlight() throws Exception {
        String req = "{\"mode\":\"single\",\"baseSeed\":7,\"env\":{\"windAvg\":5,\"turbulencePct\":30}}";
        Map<String, Object> a = runJob(req);
        Map<String, Object> b = runJob(req);
        assertEquals(a.get("apogeeM"), b.get("apogeeM"));
        assertTrue((Double) a.get("apogeeM") > 50);
    }

    @Test
    void ensembleShowsGustSpread() throws Exception {
        Map<String, Object> r = runJob("{\"mode\":\"ensemble\",\"runs\":12,"
                + "\"env\":{\"windAvg\":5,\"turbulencePct\":30}}");
        Map<?, ?> apogee = (Map<?, ?>) r.get("apogee");
        assertEquals(12.0, (Double) apogee.get("n"), 0);
        assertTrue((Double) apogee.get("sd") > 0.5, "gusts should spread apogee");
        assertTrue((Double) apogee.get("min") <= (Double) apogee.get("p50"));
    }

    @Test
    void zeroTurbulenceEnsembleIsEssentiallyFlat() throws Exception {
        // Seeds still nudge apogee by a fraction of a millimetre with gusts off (measured 3.6e-4 m);
        // with 30% turbulence the same ensemble spreads by metres.
        Map<String, Object> r = runJob("{\"mode\":\"ensemble\",\"runs\":4,"
                + "\"env\":{\"windAvg\":5,\"turbulencePct\":0}}");
        assertTrue((Double) ((Map<?, ?>) r.get("apogee")).get("sd") < 0.01);
    }

    @Test
    void windLowersApogeeInSweep() throws Exception {
        Map<String, Object> r = runJob("{\"mode\":\"sweep\",\"env\":{\"turbulencePct\":0},"
                + "\"axes\":[{\"param\":\"windAvg\",\"min\":0,\"max\":12,\"points\":3}]}");
        List<?> cells = (List<?>) r.get("cells");
        assertEquals(3, cells.size());
        double calm = (Double) ((Map<?, ?>) cells.get(0)).get("meanApogeeM");
        double windy = (Double) ((Map<?, ?>) cells.get(2)).get("meanApogeeM");
        assertTrue(calm > windy, "apogee should fall as wind rises: " + calm + " vs " + windy);
    }

    @Test
    void twoAxisSweepProducesGrid() throws Exception {
        Map<String, Object> r = runJob("{\"mode\":\"sweep\",\"env\":{\"turbulencePct\":0},\"axes\":["
                + "{\"param\":\"windAvg\",\"min\":0,\"max\":6,\"points\":2},"
                + "{\"param\":\"temp\",\"min\":0,\"max\":30,\"points\":3}]}");
        assertEquals(6, ((List<?>) r.get("cells")).size());
        assertNotNull(r.get("best"));
    }

    @Test
    void rejectsOversizedAndInvalidRequests() throws Exception {
        call("POST", "/api/jobs", "{\"mode\":\"ensemble\",\"runs\":61}", 400);
        call("POST", "/api/jobs", "{\"mode\":\"sweep\",\"axes\":[{\"param\":\"windAvg\",\"points\":10}],"
                + "\"seedsPerPoint\":7}", 400);
        call("POST", "/api/jobs", "{\"mode\":\"single\",\"env\":{\"windAvg\":500}}", 400);
        call("POST", "/api/jobs", "{\"mode\":\"nope\"}", 400);
        call("POST", "/api/jobs", "not json", 400);
        call("POST", "/api/jobs", "{\"mode\":\"single\",\"rocket\":\"missing\"}", 400);
        call("GET", "/api/jobs/000000000000000000", null, 404);
        call("GET", "/api/jobs/../etc", null, 404);
    }

    @Test
    void rejectsGarbageUpload() throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(base + "/api/rockets"))
                .POST(HttpRequest.BodyPublishers.ofString("this is not a rocket")).build();
        HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString());
        assertEquals(400, r.statusCode());
    }

    @Test
    void csvDownloadHasOneRowPerFlight() throws Exception {
        Map<String, Object> created = call("POST", "/api/jobs",
                "{\"mode\":\"ensemble\",\"runs\":3,\"env\":{\"turbulencePct\":20}}", 202);
        String id = (String) created.get("id");
        for (int i = 0; i < 300; i++) {
            if ("done".equals(call("GET", "/api/jobs/" + id, null, 200).get("state"))) break;
            Thread.sleep(200);
        }
        HttpResponse<String> csv = http.send(HttpRequest.newBuilder(URI.create(base + "/api/jobs/" + id + "/csv"))
                .GET().build(), HttpResponse.BodyHandlers.ofString());
        assertEquals(200, csv.statusCode());
        assertEquals(4, csv.body().trim().split("\n").length);
    }

    @Test
    void servesTheUi() throws Exception {
        HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(base + "/")).GET().build(),
                HttpResponse.BodyHandlers.ofString());
        assertEquals(200, r.statusCode());
        assertTrue(r.body().contains("ARC-SIM"));
        assertEquals("nosniff", r.headers().firstValue("X-Content-Type-Options").orElse(""));
        HttpResponse<String> miss = http.send(HttpRequest.newBuilder(URI.create(base + "/..%2fpom.xml")).GET().build(),
                HttpResponse.BodyHandlers.ofString());
        assertEquals(404, miss.statusCode());
    }
}
