package com.arc.sim.web;

import org.junit.jupiter.api.Test;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AccessKeyTest {
    @Test
    void apiNeedsTheKeyButHealthAndConfigDoNot() throws Exception {
        System.setProperty("PORT", "0");
        System.setProperty("ARC_SIM_ACCESS_KEY", "s3cret-test-key");
        System.setProperty("ARC_ALLOW_UPLOAD", "false");
        WebServer s = WebServer.start(Config.fromEnv());
        try {
            HttpClient c = HttpClient.newHttpClient();
            String base = "http://127.0.0.1:" + s.port();
            assertEquals(200, c.send(HttpRequest.newBuilder(URI.create(base + "/api/health")).build(),
                    HttpResponse.BodyHandlers.ofString()).statusCode());
            assertEquals(200, c.send(HttpRequest.newBuilder(URI.create(base + "/api/config")).build(),
                    HttpResponse.BodyHandlers.ofString()).statusCode());
            assertEquals(401, c.send(HttpRequest.newBuilder(URI.create(base + "/api/rockets")).build(),
                    HttpResponse.BodyHandlers.ofString()).statusCode());
            assertEquals(401, c.send(HttpRequest.newBuilder(URI.create(base + "/api/rockets"))
                    .header("X-Access-Key", "wrong").build(), HttpResponse.BodyHandlers.ofString()).statusCode());
            assertEquals(200, c.send(HttpRequest.newBuilder(URI.create(base + "/api/rockets"))
                    .header("X-Access-Key", "s3cret-test-key").build(), HttpResponse.BodyHandlers.ofString()).statusCode());
            assertEquals(403, c.send(HttpRequest.newBuilder(URI.create(base + "/api/rockets"))
                    .header("X-Access-Key", "s3cret-test-key")
                    .POST(HttpRequest.BodyPublishers.ofString("x")).build(), HttpResponse.BodyHandlers.ofString()).statusCode());
        } finally {
            s.stop();
            System.clearProperty("PORT");
            System.clearProperty("ARC_SIM_ACCESS_KEY");
            System.clearProperty("ARC_ALLOW_UPLOAD");
        }
    }
}
