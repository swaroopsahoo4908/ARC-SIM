package com.arc.sim.web;

import com.arc.sim.CadModel;
import com.arc.sim.EnvironmentPoint;
import com.arc.sim.LaunchSite;
import com.arc.sim.MeshExporter;
import com.arc.sim.RocketGeometryExtractor;
import com.arc.sim.SimRunner;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/** Holds the bundled demo rocket and any uploaded .ork files, on local temp storage, under random ids. */
final class RocketStore {
    private static final int MAX_UPLOADS = 20;
    private static final SecureRandom RNG = new SecureRandom();

    static final class Entry {
        final String id;
        final String label;
        final Path path;
        final boolean demo;
        final long createdMs = System.currentTimeMillis();
        String rocketName = "";
        int stages;
        double baselineApogeeM = Double.NaN;
        double baselineTimeS = Double.NaN;
        /** Null when the airframe is the ARC V2 CAD airframe; otherwise why the CAD model cannot be shown. */
        String cadMismatch = "not checked";
        private byte[] cadMeshGz, generatedMeshGz;

        Entry(String id, String label, Path path, boolean demo) {
            this.id = id;
            this.label = label;
            this.path = path;
            this.demo = demo;
        }

        Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", id);
            m.put("label", label);
            m.put("demo", demo);
            m.put("rocketName", rocketName);
            m.put("stages", stages);
            m.put("baselineApogeeM", baselineApogeeM);
            m.put("baselineFlightTimeS", baselineTimeS);
            m.put("cadAvailable", cadMismatch == null);
            if (cadMismatch != null) m.put("cadNote", cadMismatch);
            return m;
        }
    }

    private final Path dir;
    private final Map<String, Entry> entries = new LinkedHashMap<>();

    RocketStore() throws IOException {
        this.dir = Files.createTempDirectory("arc-sim-web-");
        this.dir.toFile().deleteOnExit();
    }

    /** The ARC V2 CAD template is the demo rocket; CSWARCMOD1E stays available as the earlier design. */
    synchronized Entry addDemo() throws Exception {
        Entry demo = addBundled("demo", "ARC V2 (CAD template, PLA Basic, 306 g)", "/rockets/demo.ork");
        addBundled("demo-aero", "ARC V2 (CAD template, PLA Aero, 180.6 g)", "/rockets/demo_aero.ork");
        addBundled("mod1e", "CSWARCMOD1E (earlier design)", "/rockets/mod1e.ork");
        return demo;
    }

    private Entry addBundled(String id, String label, String resource) throws Exception {
        Path p = dir.resolve(id + ".ork");
        try (InputStream in = RocketStore.class.getResourceAsStream(resource)) {
            if (in == null) throw new IllegalStateException("bundled rocket " + resource + " is missing from the jar");
            Files.copy(in, p, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
        p.toFile().deleteOnExit();
        Entry e = new Entry(id, label, p, true);
        inspect(e);
        entries.put(e.id, e);
        return e;
    }

    /**
     * Gzip-compressed triangle soup for the 3D view. Layout: uint32 triangle count, float32 x 9 per triangle
     * (millimetres, x from the nose tip aft), then one class byte per triangle (0 airframe, 1 fin, 2 internal/other).
     * cad=true returns the CAD model when the rocket is the ARC V2 airframe; otherwise the generated mesh.
     * The returned note says which one was used and why.
     */
    Mesh mesh(Entry e, boolean cad) throws Exception {
        synchronized (e) {
            boolean useCad = cad && e.cadMismatch == null;
            byte[] cached = useCad ? e.cadMeshGz : e.generatedMeshGz;
            if (cached == null) {
                SimRunner runner = new SimRunner(e.path.toFile());
                RocketGeometryExtractor.Geometry g = RocketGeometryExtractor.extract(runner.getDocument().getRocket());
                CadModel.Flat flat = useCad ? CadModel.get().build(g, false) : MeshExporter.generatedFlat(g);
                cached = pack(flat);
                if (useCad) e.cadMeshGz = cached; else e.generatedMeshGz = cached;
            }
            String note = useCad ? "ARC V2 CAD model"
                    : cad ? "Generated mesh (the ARC V2 CAD model is not used because " + e.cadMismatch + ")"
                    : "Generated mesh";
            return new Mesh(cached, useCad ? "cad" : "generated", note);
        }
    }

    record Mesh(byte[] gz, String source, String note) {
    }

    private static byte[] pack(CadModel.Flat f) throws IOException {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream(f.xyz.length * 2);
        try (java.io.DataOutputStream out = new java.io.DataOutputStream(
                new java.util.zip.GZIPOutputStream(bos, 1 << 16))) {
            java.nio.ByteBuffer head = java.nio.ByteBuffer.allocate(4).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            head.putInt(f.triCount());
            out.write(head.array());
            java.nio.ByteBuffer body = java.nio.ByteBuffer.allocate(f.xyz.length * 4).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            for (float v : f.xyz) body.putFloat(v);
            out.write(body.array());
            out.write(f.cls);
        }
        return bos.toByteArray();
    }

    /** Validates by loading the file and flying it once at standard conditions before accepting it. */
    Entry addUpload(byte[] data, String filename) {
        String id = randomId();
        Path p = dir.resolve(id + ".ork");
        try {
            Files.write(p, data);
            Entry e = new Entry(id, cleanLabel(filename), p, false);
            inspect(e);
            synchronized (this) {
                entries.put(id, e);
                evictOldUploads();
            }
            return e;
        } catch (ApiException ex) {
            silentDelete(p);
            throw ex;
        } catch (Exception ex) {
            silentDelete(p);
            String why = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
            throw ApiException.bad("Could not read that file as an OpenRocket design: " + why);
        }
    }

    synchronized Entry get(String id) {
        return entries.get(id);
    }

    synchronized List<Entry> list() {
        return new ArrayList<>(entries.values());
    }

    /** Drops uploads older than the cutoff unless a queued or running job still points at them. */
    synchronized void purge(long cutoffMs, Predicate<String> inUse) {
        List<Entry> old = new ArrayList<>();
        for (Entry e : entries.values()) {
            if (!e.demo && e.createdMs < cutoffMs && !inUse.test(e.id)) old.add(e);
        }
        for (Entry e : old) {
            entries.remove(e.id);
            silentDelete(e.path);
        }
    }

    private void evictOldUploads() {
        List<Entry> uploads = new ArrayList<>();
        for (Entry e : entries.values()) if (!e.demo) uploads.add(e);
        uploads.sort(Comparator.comparingLong(x -> x.createdMs));
        while (uploads.size() > MAX_UPLOADS) {
            Entry gone = uploads.remove(0);
            entries.remove(gone.id);
            silentDelete(gone.path);
        }
    }

    private static void inspect(Entry e) throws Exception {
        SimRunner runner = new SimRunner(e.path.toFile());
        if (runner.getDocument().getSimulationCount() == 0) {
            throw ApiException.bad("That design has no simulation in it. Add one in OpenRocket (motor, launch rod "
                    + "and recovery come from simulation 1) and save the file again.");
        }
        try {
            e.rocketName = runner.getDocument().getRocket().getName();
            e.stages = runner.getDocument().getRocket().getStageCount();
        } catch (RuntimeException ignored) {
            // metadata is cosmetic; the baseline flight below is the real validity check
        }
        SimRunner.FlightResult r = runner.run(EnvironmentPoint.stpBaseline(LaunchSite.MDRA_SOD_FARM));
        if (!r.ok) {
            throw ApiException.bad("The baseline flight failed: " + r.error);
        }
        e.baselineApogeeM = r.apogeeM;
        e.baselineTimeS = r.flightTimeS;
        try {
            e.cadMismatch = CadModel.get().mismatch(RocketGeometryExtractor.extract(runner.getDocument().getRocket()));
        } catch (RuntimeException ex) {
            e.cadMismatch = "its geometry could not be read";
        }
    }

    private static String cleanLabel(String filename) {
        String s = filename == null ? "" : filename.replaceAll("[^A-Za-z0-9._ \\-()]", "_").trim();
        if (s.length() > 60) s = s.substring(0, 60);
        return s.isEmpty() ? "uploaded.ork" : s;
    }

    private static String randomId() {
        byte[] b = new byte[6];
        RNG.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    private static void silentDelete(Path p) {
        try {
            Files.deleteIfExists(p);
        } catch (IOException ignored) {
            // temp file; the OS will reclaim it
        }
    }
}
