package com.arc.sim.web;

import com.arc.sim.EnvironmentPoint;
import com.arc.sim.LaunchSite;
import com.arc.sim.MiniJson;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Turns a client's JSON request into a validated list of flights. All limits live here. */
final class JobRequests {
    private JobRequests() {}

    /** The five environment knobs a client can set or sweep. Order matches the arrays below. */
    static final String[] PARAMS = {"windAvg", "turbulencePct", "temp", "pressure", "rodAngle"};
    static final String[] LABELS = {"Wind speed (m/s)", "Turbulence (%)", "Temperature (C)", "Pressure (mbar)",
            "Rod angle (deg)"};
    static final double[] LO = {0, 0, -40, 800, 0};
    static final double[] HI = {40, 100, 60, 1100, 20};
    static final double[] DEFAULT = {5, 10, 15, 1013.25, 0};

    private static final long GOLDEN = 0x9E3779B97F4A7C15L;

    static Job build(String id, Map<String, Object> req, RocketStore store, Config cfg, String ip) {
        String rocketId = str(req, "rocket", "demo");
        RocketStore.Entry rocket = store.get(rocketId);
        if (rocket == null) throw ApiException.bad("Unknown rocket: " + rocketId);

        String mode = str(req, "mode", "");
        if (!mode.equals("single") && !mode.equals("ensemble") && !mode.equals("sweep")) {
            throw ApiException.bad("mode must be single, ensemble or sweep");
        }

        Map<String, Object> envMap = map(req, "env");
        double[] p = new double[PARAMS.length];
        for (int i = 0; i < PARAMS.length; i++) {
            p[i] = num(envMap, PARAMS[i], DEFAULT[i], LO[i], HI[i]);
        }
        double windDir = num(envMap, "windDirDeg", 0, 0, 360);
        LaunchSite site = site(envMap);

        Job.Targets t = new Job.Targets();
        Map<String, Object> tm = map(req, "targets");
        t.apogeeM = num(tm, "apogeeM", t.apogeeM, 1, 20000);
        t.apogeeTolM = num(tm, "apogeeTolM", t.apogeeTolM, 0.001, 5000);
        t.timeS = num(tm, "timeS", t.timeS, 0.1, 3600);
        t.timeTolS = num(tm, "timeTolS", t.timeTolS, 0.001, 3600);

        long baseSeed = (long) num(req, "baseSeed", 1, 0, 1e12);

        List<Job.Task> tasks = new ArrayList<>();
        List<Job.Axis> axes = new ArrayList<>();
        int seedsPerPoint = 1;

        switch (mode) {
            case "single" -> tasks.add(task(0, 0, 0, 0, baseSeed, p, windDir, site, null, null, 0, 0));
            case "ensemble" -> {
                int n = (int) num(req, "runs", 100, 2, cfg.maxSimsPerJob);
                for (int k = 0; k < n; k++) {
                    tasks.add(task(0, 0, 0, 0, baseSeed + k * GOLDEN, p, windDir, site, null, null, 0, 0));
                }
            }
            default -> {
                Object rawAxes = req.get("axes");
                if (!(rawAxes instanceof List<?> list) || list.isEmpty() || list.size() > 2) {
                    throw ApiException.bad("sweep needs 1 or 2 axes");
                }
                for (Object o : list) {
                    if (!(o instanceof Map<?, ?> am)) throw ApiException.bad("each axis must be an object");
                    @SuppressWarnings("unchecked") Map<String, Object> a = (Map<String, Object>) am;
                    String name = str(a, "param", "");
                    int idx = indexOf(name);
                    if (idx < 0) throw ApiException.bad("Unknown sweep parameter: " + name);
                    double lo = num(a, "min", LO[idx], LO[idx], HI[idx]);
                    double hi = num(a, "max", HI[idx], LO[idx], HI[idx]);
                    if (hi < lo) throw ApiException.bad("axis " + name + ": max is below min");
                    int pts = (int) num(a, "points", 10, 1, 200);
                    axes.add(new Job.Axis(name, LABELS[idx], lo, hi, pts));
                }
                if (axes.size() == 2 && axes.get(0).param().equals(axes.get(1).param())) {
                    throw ApiException.bad("the two axes must be different parameters");
                }
                seedsPerPoint = (int) num(req, "seedsPerPoint", 1, 1, cfg.maxSimsPerJob);
                long cells = (long) axes.get(0).points() * (axes.size() == 2 ? axes.get(1).points() : 1);
                long total = cells * seedsPerPoint;
                if (total > cfg.maxSimsPerJob) {
                    throw ApiException.bad("That sweep is " + total + " flights; this server allows at most "
                            + cfg.maxSimsPerJob + " per job.");
                }
                Job.Axis ax = axes.get(0);
                Job.Axis ay = axes.size() == 2 ? axes.get(1) : null;
                int ny = ay == null ? 1 : ay.points();
                for (int iy = 0; iy < ny; iy++) {
                    for (int ix = 0; ix < ax.points(); ix++) {
                        for (int k = 0; k < seedsPerPoint; k++) {
                            long cellIndex = (long) iy * ax.points() + ix;
                            long seed = baseSeed + (cellIndex * seedsPerPoint + k) * GOLDEN;
                            tasks.add(task(ix, iy, ax.value(ix), ay == null ? 0 : ay.value(iy), seed, p, windDir,
                                    site, ax, ay, ix, iy));
                        }
                    }
                }
            }
        }
        return new Job(id, mode, rocket, tasks, t, axes, seedsPerPoint, ip);
    }

    private static Job.Task task(int ix, int iy, double x, double y, long seed, double[] base, double windDir,
                                 LaunchSite site, Job.Axis ax, Job.Axis ay, int axIdx, int ayIdx) {
        double[] v = base.clone();
        if (ax != null) v[indexOf(ax.param())] = ax.value(axIdx);
        if (ay != null) v[indexOf(ay.param())] = ay.value(ayIdx);
        EnvironmentPoint env = new EnvironmentPoint(v[0], 0.0, v[1] / 100.0, windDir, v[2], v[3], v[4], site);
        return new Job.Task(ix, iy, x, y, seed, env);
    }

    private static LaunchSite site(Map<String, Object> env) {
        String s = str(env, "site", "MDRA_SOD_FARM");
        if (s.equalsIgnoreCase("CUSTOM")) {
            double lat = num(env, "lat", Double.NaN, -90, 90);
            double lon = num(env, "lon", Double.NaN, -180, 180);
            double alt = num(env, "altM", 0, -500, 6000);
            return LaunchSite.custom(lat, lon, alt);
        }
        try {
            return LaunchSite.parse(s);
        } catch (IllegalArgumentException e) {
            throw ApiException.bad("Unknown site: " + s);
        }
    }

    private static int indexOf(String param) {
        for (int i = 0; i < PARAMS.length; i++) if (PARAMS[i].equals(param)) return i;
        return -1;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Map<String, Object> m, String key) {
        Object v = m.get(key);
        if (v == null) return new LinkedHashMap<>();
        if (!(v instanceof Map)) throw ApiException.bad(key + " must be an object");
        return (Map<String, Object>) v;
    }

    private static String str(Map<String, Object> m, String key, String def) {
        Object v = m.get(key);
        if (v == null) return def;
        if (!(v instanceof String)) throw ApiException.bad(key + " must be a string");
        return (String) v;
    }

    /** Reads a number, applying a default when absent. A NaN default makes the field required. */
    private static double num(Map<String, Object> m, String key, double def, double lo, double hi) {
        Object v = m.get(key);
        double d;
        if (v == null) {
            if (Double.isNaN(def)) throw ApiException.bad(key + " is required");
            return def;
        }
        if (!(v instanceof Number)) throw ApiException.bad(key + " must be a number");
        d = ((Number) v).doubleValue();
        if (Double.isNaN(d) || d < lo || d > hi) {
            throw ApiException.bad(key + " must be between " + lo + " and " + hi);
        }
        return d;
    }

    /** Parse helper kept here so the server has one place that turns bytes into a request map. */
    @SuppressWarnings("unchecked")
    static Map<String, Object> parseBody(byte[] body) {
        try {
            Object o = MiniJson.parse(new String(body, java.nio.charset.StandardCharsets.UTF_8));
            if (!(o instanceof Map)) throw ApiException.bad("request body must be a JSON object");
            return (Map<String, Object>) o;
        } catch (ApiException e) {
            throw e;
        } catch (RuntimeException e) {
            throw ApiException.bad("request body is not valid JSON");
        }
    }
}
