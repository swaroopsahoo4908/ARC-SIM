package com.arc.sim.web;

/**
 * Runtime settings. Every value comes from an environment variable (or a JVM system property of the same name,
 * which the tests use), so one image deploys unchanged anywhere.
 */
final class Config {
    final int port;
    final int threads;
    final int maxConcurrentJobs;
    final int maxSimsPerJob;
    final int queueLimit;
    final boolean allowUpload;
    final int maxUploadBytes;
    final String accessKey;
    final int ratePerMin;
    final boolean trustProxy;
    final int jobTtlMin;
    final String sourceUrl;

    private Config() {
        port = intVal("PORT", 8080, 0, 65535);
        threads = intVal("ARC_SIM_THREADS", Math.max(1, Runtime.getRuntime().availableProcessors()), 1, 256);
        maxConcurrentJobs = intVal("ARC_MAX_CONCURRENT_JOBS", 1, 1, 16);
        maxSimsPerJob = intVal("ARC_MAX_SIMS_PER_JOB", 2000, 1, 1_000_000);
        queueLimit = intVal("ARC_QUEUE_LIMIT", 8, 0, 1000);
        allowUpload = !"false".equalsIgnoreCase(raw("ARC_ALLOW_UPLOAD", "true"));
        maxUploadBytes = intVal("ARC_MAX_UPLOAD_MB", 5, 1, 100) * 1024 * 1024;
        accessKey = raw("ARC_SIM_ACCESS_KEY", "");
        ratePerMin = intVal("ARC_RATE_PER_MIN", 30, 1, 100_000);
        trustProxy = "true".equalsIgnoreCase(raw("ARC_TRUST_PROXY", "false"));
        jobTtlMin = intVal("ARC_JOB_TTL_MIN", 120, 1, 100_000);
        sourceUrl = raw("ARC_SOURCE_URL", "");
    }

    static Config fromEnv() {
        return new Config();
    }

    private static String raw(String name, String def) {
        String v = System.getProperty(name);
        if (v == null) v = System.getenv(name);
        return (v == null || v.isBlank()) ? def : v.trim();
    }

    private static int intVal(String name, int def, int min, int max) {
        String v = raw(name, null);
        if (v == null) return def;
        try {
            int n = Integer.parseInt(v);
            if (n < min || n > max) {
                System.err.println("WARNING: " + name + "=" + v + " is outside " + min + ".." + max + "; using " + def);
                return def;
            }
            return n;
        } catch (NumberFormatException e) {
            System.err.println("WARNING: " + name + "=" + v + " is not a number; using " + def);
            return def;
        }
    }
}
