package com.arc.sim.web;

/** A request problem that maps straight onto an HTTP status and a one-line message for the client. */
final class ApiException extends RuntimeException {
    final int status;

    ApiException(int status, String message) {
        super(message);
        this.status = status;
    }

    static ApiException bad(String message) {
        return new ApiException(400, message);
    }
}
