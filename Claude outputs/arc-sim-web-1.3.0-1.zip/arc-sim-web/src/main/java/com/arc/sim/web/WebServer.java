package com.arc.sim.web;

import com.arc.sim.LaunchSite;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** ARC-SIM web release: a small JSON API over the OpenRocket-based engine, plus the static browser UI. */
public final class WebServer {
    static final String VERSION = "1.3.0-web";

    private final Config cfg;
    private final RocketStore rockets;
    private final JobManager jobs;
    private final HttpServer http;
    private final ScheduledExecutorService janitor = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "arc-sim-janitor");
        t.setDaemon(true);
        return t;
    });
    private final Map<String, Deque<Long>> hits = new HashMap<>();

    private WebServer(Config cfg) throws Exception {
        this.cfg = cfg;
        this.rockets = new RocketStore();
        this.rockets.addDemo();
        this.jobs = new JobManager(cfg, rockets);
        this.http = HttpServer.create(new InetSocketAddress(cfg.port), 128);
        this.http.createContext("/", this::handle);
        this.http.setExecutor(Executors.newFixedThreadPool(8, r -> {
            Thread t = new Thread(r, "arc-sim-http");
            t.setDaemon(true);
            return t;
        }));
        janitor.scheduleWithFixedDelay(this::sweepOld, 1, 1, TimeUnit.MINUTES);
    }

    static WebServer start(Config cfg) throws Exception {
        WebServer s = new WebServer(cfg);
        s.http.start();
        return s;
    }

    int port() {
        return http.getAddress().getPort();
    }

    void stop() {
        http.stop(0);
        jobs.stop();
        janitor.shutdownNow();
    }

    public static void main(String[] args) throws Exception {
        Config cfg = Config.fromEnv();
        WebServer s = start(cfg);
        System.out.println("ARC-SIM web " + VERSION + " listening on port " + s.port() + " with " + cfg.threads
                + " worker threads, max " + cfg.maxSimsPerJob + " flights per job, uploads "
                + (cfg.allowUpload ? "on" : "off") + ", access key " + (cfg.accessKey.isEmpty() ? "off" : "on"));
        if (cfg.sourceUrl.isEmpty()) {
            System.out.println("NOTE: ARC_SOURCE_URL is not set. ARC-SIM is AGPL-3.0, so a public deployment must "
                    + "offer its users a link to the source code. Set ARC_SOURCE_URL to your repository URL.");
        }
        Runtime.getRuntime().addShutdownHook(new Thread(s::stop));
        Thread.currentThread().join();
    }

    // ------------------------------------------------------------------------------------------------------

    private void handle(HttpExchange ex) throws IOException {
        try {
            securityHeaders(ex);
            String path = ex.getRequestURI().getPath();
            String method = ex.getRequestMethod();
            if (path.startsWith("/api/")) {
                api(ex, method, path);
            } else if (method.equals("GET") || method.equals("HEAD")) {
                staticFile(ex, path);
            } else {
                throw new ApiException(405, "Method not allowed");
            }
        } catch (ApiException e) {
            json(ex, e.status, Map.of("error", e.getMessage()));
        } catch (Exception e) {
            System.err.println("request failed: " + e);
            json(ex, 500, Map.of("error", "Internal error"));
        } finally {
            ex.close();
        }
    }

    private void api(HttpExchange ex, String method, String path) throws Exception {
        if (path.equals("/api/health") && method.equals("GET")) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("status", "ok");
            m.put("version", VERSION);
            m.put("activeJobs", jobs.activeCount());
            json(ex, 200, m);
            return;
        }
        if (path.equals("/api/config") && method.equals("GET")) {
            json(ex, 200, configJson());
            return;
        }
        requireKey(ex);

        if (path.equals("/api/rockets")) {
            if (method.equals("GET")) {
                List<Object> list = new ArrayList<>();
                for (RocketStore.Entry e : rockets.list()) list.add(e.toJson());
                json(ex, 200, Map.of("rockets", list));
            } else if (method.equals("POST")) {
                if (!cfg.allowUpload) throw new ApiException(403, "Uploads are turned off on this server.");
                rateLimit(ex);
                byte[] body = readBody(ex, cfg.maxUploadBytes);
                if (body.length == 0) throw ApiException.bad("The upload is empty.");
                String name = ex.getRequestHeaders().getFirst("X-Filename");
                RocketStore.Entry e = rockets.addUpload(body, name);
                System.out.println("rocket " + e.id + " uploaded (" + body.length + " bytes)");
                json(ex, 201, e.toJson());
            } else {
                throw new ApiException(405, "Method not allowed");
            }
            return;
        }

        if (path.startsWith("/api/rockets/") && path.endsWith("/mesh")) {
            if (!method.equals("GET")) throw new ApiException(405, "Method not allowed");
            String id = path.substring("/api/rockets/".length(), path.length() - "/mesh".length());
            RocketStore.Entry e = rockets.get(id);
            if (e == null) throw new ApiException(404, "No such rocket.");
            String q = ex.getRequestURI().getQuery();
            boolean cad = q == null || !q.contains("source=generated");
            RocketStore.Mesh mesh = rockets.mesh(e, cad);
            var h = ex.getResponseHeaders();
            h.set("Cache-Control", "no-store");
            h.set("X-Mesh-Source", mesh.source());
            h.set("X-Mesh-Note", mesh.note().replaceAll("[^\\x20-\\x7E]", "?"));
            h.set("Access-Control-Expose-Headers", "X-Mesh-Source, X-Mesh-Note");
            h.set("Content-Encoding", "gzip");
            bytes(ex, 200, "application/octet-stream", mesh.gz(), null);
            return;
        }

        if (path.equals("/api/jobs") && method.equals("POST")) {
            rateLimit(ex);
            Map<String, Object> req = JobRequests.parseBody(readBody(ex, 64 * 1024));
            Job job = jobs.submit(req, clientIp(ex));
            json(ex, 202, Map.of("id", job.id, "total", job.tasks.size()));
            return;
        }

        if (path.startsWith("/api/jobs/")) {
            String rest = path.substring("/api/jobs/".length());
            boolean csv = rest.endsWith("/csv");
            String id = csv ? rest.substring(0, rest.length() - 4) : rest;
            Job job = id.matches("[0-9a-f]{18}") ? jobs.get(id) : null;
            if (job == null) throw new ApiException(404, "No such job (it may have expired).");
            if (csv && method.equals("GET")) {
                bytes(ex, 200, "text/csv; charset=utf-8", Summaries.csv(job).getBytes(StandardCharsets.UTF_8),
                        "attachment; filename=\"arc-sim-" + job.id + ".csv\"");
            } else if (!csv && method.equals("GET")) {
                json(ex, 200, status(job));
            } else if (!csv && method.equals("DELETE")) {
                jobs.cancel(job);
                json(ex, 200, status(job));
            } else {
                throw new ApiException(405, "Method not allowed");
            }
            return;
        }
        throw new ApiException(404, "Not found");
    }

    private Map<String, Object> configJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("version", VERSION);
        m.put("requiresKey", !cfg.accessKey.isEmpty());
        m.put("allowUpload", cfg.allowUpload);
        m.put("maxUploadMb", cfg.maxUploadBytes / (1024 * 1024));
        m.put("maxSimsPerJob", cfg.maxSimsPerJob);
        m.put("threads", cfg.threads);
        m.put("sourceUrl", cfg.sourceUrl);
        List<Object> params = new ArrayList<>();
        for (int i = 0; i < JobRequests.PARAMS.length; i++) {
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("id", JobRequests.PARAMS[i]);
            p.put("label", JobRequests.LABELS[i]);
            p.put("min", JobRequests.LO[i]);
            p.put("max", JobRequests.HI[i]);
            p.put("default", JobRequests.DEFAULT[i]);
            params.add(p);
        }
        m.put("params", params);
        List<Object> sites = new ArrayList<>();
        sites.add(site("MDRA_SOD_FARM", LaunchSite.MDRA_SOD_FARM));
        sites.add(site("SPAAR_LANCASTER", LaunchSite.SPAAR_LANCASTER));
        m.put("sites", sites);
        Job.Targets t = new Job.Targets();
        m.put("targets", t.toJson());
        return m;
    }

    private static Map<String, Object> site(String id, LaunchSite s) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("label", s.label);
        m.put("lat", s.latitudeDeg);
        m.put("lon", s.longitudeDeg);
        m.put("altM", s.altitudeM);
        return m;
    }

    private Map<String, Object> status(Job job) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", job.id);
        m.put("mode", job.mode);
        m.put("state", job.state.name().toLowerCase());
        int done = job.done.get();
        int total = job.tasks.size();
        m.put("done", done);
        m.put("total", total);
        long now = System.currentTimeMillis();
        long end = job.finishedMs != 0 ? job.finishedMs : now;
        double elapsed = job.startedMs == 0 ? 0 : (end - job.startedMs) / 1000.0;
        m.put("elapsedS", elapsed);
        if (job.state == Job.State.RUNNING && done > 0) {
            m.put("etaS", elapsed / done * (total - done));
        }
        if (job.state == Job.State.QUEUED) m.put("queuePosition", jobs.queuePosition(job));
        m.put("rocket", job.rocket.toJson());
        if (job.error != null) m.put("error", job.error);
        if (job.result != null) m.put("result", job.result);
        return m;
    }

    // ------------------------------------------------------------------------------------------------------

    private void requireKey(HttpExchange ex) {
        if (cfg.accessKey.isEmpty()) return;
        String given = ex.getRequestHeaders().getFirst("X-Access-Key");
        byte[] a = (given == null ? "" : given).getBytes(StandardCharsets.UTF_8);
        byte[] b = cfg.accessKey.getBytes(StandardCharsets.UTF_8);
        if (!MessageDigest.isEqual(a, b)) throw new ApiException(401, "Access key required.");
    }

    private String clientIp(HttpExchange ex) {
        if (cfg.trustProxy) {
            String fwd = ex.getRequestHeaders().getFirst("X-Forwarded-For");
            if (fwd != null && !fwd.isBlank()) return fwd.split(",")[0].trim();
        }
        return ex.getRemoteAddress().getAddress().getHostAddress();
    }

    private void rateLimit(HttpExchange ex) {
        String ip = clientIp(ex);
        long now = System.currentTimeMillis();
        synchronized (hits) {
            Deque<Long> q = hits.computeIfAbsent(ip, k -> new ArrayDeque<>());
            while (!q.isEmpty() && now - q.peekFirst() > 60_000) q.pollFirst();
            if (q.size() >= cfg.ratePerMin) throw new ApiException(429, "Too many requests. Slow down a little.");
            q.addLast(now);
        }
    }

    private void sweepOld() {
        try {
            long now = System.currentTimeMillis();
            long cutoff = now - cfg.jobTtlMin * 60_000L;
            jobs.purge(cutoff);
            rockets.purge(cutoff, jobs::rocketInUse);
            synchronized (hits) {
                hits.values().removeIf(q -> q.isEmpty() || now - q.peekLast() > 60_000);
            }
        } catch (RuntimeException e) {
            System.err.println("janitor: " + e);
        }
    }

    private static byte[] readBody(HttpExchange ex, int limit) throws IOException {
        String len = ex.getRequestHeaders().getFirst("Content-Length");
        if (len != null) {
            try {
                if (Long.parseLong(len) > limit) throw new ApiException(413, "Request body is too large.");
            } catch (NumberFormatException e) {
                throw ApiException.bad("Bad Content-Length");
            }
        }
        try (InputStream in = ex.getRequestBody()) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > limit) throw new ApiException(413, "Request body is too large.");
            }
            return out.toByteArray();
        }
    }

    // ------------------------------------------------------------------------------------------------------

    private void staticFile(HttpExchange ex, String path) throws IOException {
        String name = path.equals("/") ? "index.html" : path.substring(1);
        if (!name.matches("[A-Za-z0-9_\\-]+(\\.[A-Za-z0-9]+)?")) throw new ApiException(404, "Not found");
        byte[] data;
        try (InputStream in = WebServer.class.getResourceAsStream("/web/" + name)) {
            if (in == null) throw new ApiException(404, "Not found");
            data = in.readAllBytes();
        }
        String type = name.endsWith(".html") ? "text/html; charset=utf-8"
                : name.endsWith(".js") ? "text/javascript; charset=utf-8"
                : name.endsWith(".css") ? "text/css; charset=utf-8"
                : name.endsWith(".svg") ? "image/svg+xml"
                : "application/octet-stream";
        ex.getResponseHeaders().set("Cache-Control", name.endsWith(".html") ? "no-cache" : "public, max-age=300");
        bytes(ex, 200, type, data, null);
    }

    private static void securityHeaders(HttpExchange ex) {
        var h = ex.getResponseHeaders();
        h.set("X-Content-Type-Options", "nosniff");
        h.set("Referrer-Policy", "no-referrer");
        h.set("X-Frame-Options", "DENY");
        h.set("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                + "img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    }

    private static void json(HttpExchange ex, int status, Object body) throws IOException {
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        bytes(ex, status, "application/json; charset=utf-8", Json.write(body).getBytes(StandardCharsets.UTF_8), null);
    }

    private static void bytes(HttpExchange ex, int status, String type, byte[] data, String disposition)
            throws IOException {
        ex.getResponseHeaders().set("Content-Type", type);
        if (disposition != null) ex.getResponseHeaders().set("Content-Disposition", disposition);
        boolean head = ex.getRequestMethod().equals("HEAD");
        ex.sendResponseHeaders(status, head ? -1 : data.length);
        if (!head) {
            try (OutputStream os = ex.getResponseBody()) {
                os.write(data);
            }
        }
    }
}
