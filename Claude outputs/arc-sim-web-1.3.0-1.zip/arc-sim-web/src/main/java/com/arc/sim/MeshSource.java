package com.arc.sim;

/**
 * Web build of the shared mesh-source setting. The desktop app keeps this in its config file; on the server the
 * choice is made per request (see the mesh endpoint), so this only supplies the default.
 */
public final class MeshSource {
    private MeshSource() {
    }

    public static boolean useCad() {
        return true;
    }
}
