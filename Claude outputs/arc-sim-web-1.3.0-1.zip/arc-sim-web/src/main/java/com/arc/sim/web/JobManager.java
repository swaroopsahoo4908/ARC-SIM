package com.arc.sim.web;

import com.arc.sim.SimRunner;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicInteger;

/** Queues jobs, runs each across a worker pool (one SimRunner per worker), and keeps results for a while. */
final class JobManager {
    private static final int MAX_STORED_JOBS = 200;
    private static final SecureRandom RNG = new SecureRandom();

    private final Config cfg;
    private final RocketStore rockets;
    private final Map<String, Job> jobs = new LinkedHashMap<>();
    private final LinkedBlockingDeque<Job> pending = new LinkedBlockingDeque<>();
    private final List<Thread> dispatchers = new ArrayList<>();
    private volatile boolean stopping;

    JobManager(Config cfg, RocketStore rockets) {
        this.cfg = cfg;
        this.rockets = rockets;
        for (int i = 0; i < cfg.maxConcurrentJobs; i++) {
            Thread t = new Thread(this::dispatchLoop, "arc-sim-dispatch-" + i);
            t.setDaemon(true);
            t.start();
            dispatchers.add(t);
        }
    }

    Job submit(Map<String, Object> request, String ip) {
        String id = randomId();
        Job job = JobRequests.build(id, request, rockets, cfg, ip);
        synchronized (this) {
            if (pending.size() >= cfg.queueLimit && activeRunning() >= cfg.maxConcurrentJobs) {
                throw new ApiException(429, "The queue is full. Try again in a minute.");
            }
            jobs.put(id, job);
            pending.add(job);
            trimStored();
        }
        System.out.println("job " + id + " queued: " + job.mode + ", " + job.tasks.size() + " flights, rocket "
                + job.rocket.id);
        return job;
    }

    synchronized Job get(String id) {
        return jobs.get(id);
    }

    void cancel(Job job) {
        job.cancelRequested = true;
        if (pending.remove(job)) {
            job.finishedMs = System.currentTimeMillis();
            job.state = Job.State.CANCELLED;
        }
    }

    synchronized int queuePosition(Job job) {
        int i = 0;
        for (Job j : pending) {
            i++;
            if (j == job) return i;
        }
        return 0;
    }

    synchronized int activeCount() {
        int n = 0;
        for (Job j : jobs.values()) if (j.isActive()) n++;
        return n;
    }

    synchronized boolean rocketInUse(String rocketId) {
        for (Job j : jobs.values()) if (j.isActive() && j.rocket.id.equals(rocketId)) return true;
        return false;
    }

    /** Forgets finished jobs older than the TTL. */
    synchronized void purge(long cutoffMs) {
        Iterator<Job> it = jobs.values().iterator();
        while (it.hasNext()) {
            Job j = it.next();
            if (!j.isActive() && j.finishedMs != 0 && j.finishedMs < cutoffMs) it.remove();
        }
    }

    void stop() {
        stopping = true;
        for (Thread t : dispatchers) t.interrupt();
        synchronized (this) {
            for (Job j : jobs.values()) j.cancelRequested = true;
        }
    }

    // ------------------------------------------------------------------------------------------------------

    private synchronized int activeRunning() {
        int n = 0;
        for (Job j : jobs.values()) if (j.state == Job.State.RUNNING) n++;
        return n;
    }

    private void trimStored() {
        while (jobs.size() > MAX_STORED_JOBS) {
            Iterator<Job> it = jobs.values().iterator();
            boolean removed = false;
            while (it.hasNext()) {
                Job j = it.next();
                if (!j.isActive()) {
                    it.remove();
                    removed = true;
                    break;
                }
            }
            if (!removed) return;
        }
    }

    private void dispatchLoop() {
        while (!stopping) {
            Job job;
            try {
                job = pending.take();
            } catch (InterruptedException e) {
                return;
            }
            if (job.cancelRequested) {
                job.finishedMs = System.currentTimeMillis();
                job.state = Job.State.CANCELLED;
                continue;
            }
            run(job);
        }
    }

    private void run(Job job) {
        job.startedMs = System.currentTimeMillis();
        job.state = Job.State.RUNNING;
        int workers = Math.max(1, Math.min(cfg.threads, job.tasks.size()));
        ExecutorService pool = Executors.newFixedThreadPool(workers, r -> {
            Thread t = new Thread(r, "arc-sim-worker");
            t.setDaemon(true);
            return t;
        });
        AtomicInteger next = new AtomicInteger();
        List<Future<String>> futures = new ArrayList<>();
        try {
            for (int w = 0; w < workers; w++) {
                Callable<String> body = () -> work(job, next);
                futures.add(pool.submit(body));
            }
            String failure = null;
            for (Future<String> f : futures) {
                try {
                    String r = f.get();
                    if (r != null && failure == null) failure = r;
                } catch (Exception e) {
                    if (failure == null) failure = String.valueOf(e.getMessage());
                }
            }
            if (failure != null) {
                job.error = failure;
                job.state = Job.State.FAILED;
            } else if (job.cancelRequested) {
                job.state = Job.State.CANCELLED;
            } else {
                job.result = Summaries.summarise(job);
                job.state = Job.State.DONE;
            }
        } catch (RuntimeException e) {
            job.error = e.toString();
            job.state = Job.State.FAILED;
        } finally {
            pool.shutdownNow();
            job.finishedMs = System.currentTimeMillis();
            System.out.println("job " + job.id + " " + job.state.name().toLowerCase() + " in "
                    + (job.finishedMs - job.startedMs) / 1000.0 + " s");
        }
    }

    /** Worker body: load a private copy of the rocket, then pull flights until none are left. */
    private String work(Job job, AtomicInteger next) {
        SimRunner runner;
        try {
            runner = new SimRunner(job.rocket.path.toFile());
        } catch (Exception e) {
            return "could not load the rocket: " + e.getMessage();
        }
        int i;
        while (!job.cancelRequested && !stopping && (i = next.getAndIncrement()) < job.tasks.size()) {
            Job.Task t = job.tasks.get(i);
            SimRunner.FlightResult r = runner.run(t.env(), t.seed());
            job.rows.set(i, new Job.Row(t, r.ok, r.apogeeM, r.flightTimeS, r.error));
            job.done.incrementAndGet();
        }
        return null;
    }

    private static String randomId() {
        byte[] b = new byte[9];
        RNG.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }
}
