package com.arc.sim.web;

import com.arc.sim.EnvironmentPoint;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReferenceArray;

/** One user request: a list of flights to run, their results as they arrive, and a final summary. */
final class Job {
    enum State { QUEUED, RUNNING, DONE, FAILED, CANCELLED }

    /** One flight to run. ix and iy locate it in a sweep grid; both are 0 for single and ensemble jobs. */
    record Task(int ix, int iy, double x, double y, long seed, EnvironmentPoint env) {}

    /** One finished flight. */
    record Row(Task task, boolean ok, double apogeeM, double flightTimeS, String error) {}

    static final class Targets {
        double apogeeM = 243.84;
        double apogeeTolM = 0.25;
        double timeS = 38.5;
        double timeTolS = 1.0;

        boolean meetsApogee(double apogee) {
            return Math.abs(apogee - apogeeM) <= apogeeTolM;
        }

        boolean meetsTime(double t) {
            return Math.abs(t - timeS) <= timeTolS;
        }

        Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("apogeeM", apogeeM);
            m.put("apogeeTolM", apogeeTolM);
            m.put("timeS", timeS);
            m.put("timeTolS", timeTolS);
            return m;
        }
    }

    /** Sweep axis description, also echoed back to the client. */
    record Axis(String param, String label, double min, double max, int points) {
        double value(int i) {
            return points <= 1 ? min : min + (max - min) * i / (points - 1);
        }

        double[] values() {
            double[] v = new double[points];
            for (int i = 0; i < points; i++) v[i] = value(i);
            return v;
        }
    }

    final String id;
    final String mode;
    final RocketStore.Entry rocket;
    final List<Task> tasks;
    final Targets targets;
    final List<Axis> axes;
    final int seedsPerPoint;
    final String clientIp;
    final long createdMs = System.currentTimeMillis();

    final AtomicInteger done = new AtomicInteger();
    final AtomicReferenceArray<Row> rows;
    volatile State state = State.QUEUED;
    volatile boolean cancelRequested;
    volatile long startedMs;
    volatile long finishedMs;
    volatile String error;
    volatile Map<String, Object> result;

    Job(String id, String mode, RocketStore.Entry rocket, List<Task> tasks, Targets targets, List<Axis> axes,
        int seedsPerPoint, String clientIp) {
        this.id = id;
        this.mode = mode;
        this.rocket = rocket;
        this.tasks = tasks;
        this.targets = targets;
        this.axes = axes;
        this.seedsPerPoint = seedsPerPoint;
        this.clientIp = clientIp;
        this.rows = new AtomicReferenceArray<>(tasks.size());
    }

    boolean isActive() {
        return state == State.QUEUED || state == State.RUNNING;
    }

    List<Row> finishedRows() {
        List<Row> out = new ArrayList<>(tasks.size());
        for (int i = 0; i < tasks.size(); i++) {
            Row r = rows.get(i);
            if (r != null) out.add(r);
        }
        return out;
    }
}
