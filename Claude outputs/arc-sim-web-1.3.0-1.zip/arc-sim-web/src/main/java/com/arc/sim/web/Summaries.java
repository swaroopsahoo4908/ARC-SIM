package com.arc.sim.web;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Builds the result JSON for a finished job, and its CSV export. */
final class Summaries {
    private Summaries() {}

    static Map<String, Object> summarise(Job job) {
        List<Job.Row> rows = job.finishedRows();
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("mode", job.mode);
        out.put("targets", job.targets.toJson());
        switch (job.mode) {
            case "single" -> single(job, rows, out);
            case "ensemble" -> ensemble(job, rows, out);
            default -> sweep(job, rows, out);
        }
        return out;
    }

    private static void single(Job job, List<Job.Row> rows, Map<String, Object> out) {
        Job.Row r = rows.get(0);
        out.put("ok", r.ok());
        out.put("error", r.error());
        out.put("apogeeM", r.apogeeM());
        out.put("flightTimeS", r.flightTimeS());
        if (r.ok()) {
            out.put("apogeeErrorM", r.apogeeM() - job.targets.apogeeM);
            out.put("meetsApogee", job.targets.meetsApogee(r.apogeeM()));
            out.put("meetsTime", job.targets.meetsTime(r.flightTimeS()));
        }
        out.put("seed", r.task().seed());
    }

    private static void ensemble(Job job, List<Job.Row> rows, Map<String, Object> out) {
        double[] apo = okValues(rows, true);
        double[] time = okValues(rows, false);
        out.put("runs", rows.size());
        out.put("failed", rows.size() - apo.length);
        out.put("apogee", Stats.describe(apo));
        out.put("flightTime", Stats.describe(time));
        out.put("histogram", Stats.histogram(apo, 24));
        int a = 0, t = 0, both = 0;
        for (Job.Row r : rows) {
            if (!r.ok()) continue;
            boolean ma = job.targets.meetsApogee(r.apogeeM());
            boolean mt = job.targets.meetsTime(r.flightTimeS());
            if (ma) a++;
            if (mt) t++;
            if (ma && mt) both++;
        }
        out.put("pApogee", rate(a, apo.length));
        out.put("pTime", rate(t, apo.length));
        out.put("pBoth", rate(both, apo.length));
        double[] ci = Stats.wilson95(both, apo.length);
        out.put("pBothCi95", ci);
    }

    private static void sweep(Job job, List<Job.Row> rows, Map<String, Object> out) {
        List<Map<String, Object>> axes = new ArrayList<>();
        for (Job.Axis a : job.axes) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("param", a.param());
            m.put("label", a.label());
            m.put("min", a.min());
            m.put("max", a.max());
            m.put("points", a.points());
            m.put("values", a.values());
            axes.add(m);
        }
        out.put("axes", axes);
        out.put("seedsPerPoint", job.seedsPerPoint);

        int nx = job.axes.get(0).points();
        int ny = job.axes.size() == 2 ? job.axes.get(1).points() : 1;
        List<Map<String, Object>> cells = new ArrayList<>();
        Map<String, Object> best = null;
        double bestScore = -1;
        double bestDist = Double.POSITIVE_INFINITY;
        int failedTotal = 0;
        List<List<Job.Row>> buckets = new ArrayList<>();
        for (int i = 0; i < nx * ny; i++) buckets.add(new ArrayList<>());
        for (Job.Row r : rows) buckets.get(r.task().iy() * nx + r.task().ix()).add(r);
        for (int iy = 0; iy < ny; iy++) {
            for (int ix = 0; ix < nx; ix++) {
                List<Double> ap = new ArrayList<>();
                List<Double> ft = new ArrayList<>();
                int ma = 0, mt = 0, both = 0, failed = 0;
                double x = Double.NaN, y = Double.NaN;
                for (Job.Row r : buckets.get(iy * nx + ix)) {
                    x = r.task().x();
                    y = r.task().y();
                    if (!r.ok()) {
                        failed++;
                        continue;
                    }
                    ap.add(r.apogeeM());
                    ft.add(r.flightTimeS());
                    boolean a = job.targets.meetsApogee(r.apogeeM());
                    boolean t = job.targets.meetsTime(r.flightTimeS());
                    if (a) ma++;
                    if (t) mt++;
                    if (a && t) both++;
                }
                failedTotal += failed;
                double[] apv = ap.stream().mapToDouble(Double::doubleValue).toArray();
                double[] ftv = ft.stream().mapToDouble(Double::doubleValue).toArray();
                Map<String, Object> c = new LinkedHashMap<>();
                c.put("ix", ix);
                c.put("iy", iy);
                c.put("x", x);
                c.put("y", y);
                c.put("n", apv.length);
                c.put("failed", failed);
                c.put("meanApogeeM", Stats.mean(apv));
                c.put("sdApogeeM", Stats.sd(apv));
                c.put("meanFlightTimeS", Stats.mean(ftv));
                c.put("pApogee", rate(ma, apv.length));
                c.put("pTime", rate(mt, apv.length));
                c.put("pBoth", rate(both, apv.length));
                cells.add(c);
                if (apv.length > 0) {
                    double score = (double) both / apv.length;
                    double dist = Math.abs(Stats.mean(apv) - job.targets.apogeeM);
                    if (score > bestScore || (score == bestScore && dist < bestDist)) {
                        bestScore = score;
                        bestDist = dist;
                        best = c;
                    }
                }
            }
        }
        out.put("cells", cells);
        out.put("failed", failedTotal);
        out.put("best", best);
    }

    private static double[] okValues(List<Job.Row> rows, boolean apogee) {
        return rows.stream().filter(Job.Row::ok)
                .mapToDouble(r -> apogee ? r.apogeeM() : r.flightTimeS()).toArray();
    }

    private static double rate(int hits, int n) {
        return n == 0 ? Double.NaN : (double) hits / n;
    }

    static String csv(Job job) {
        StringBuilder sb = new StringBuilder();
        String xName = job.axes.isEmpty() ? "" : job.axes.get(0).param();
        String yName = job.axes.size() > 1 ? job.axes.get(1).param() : "";
        sb.append("run,seed,");
        if (!xName.isEmpty()) sb.append(xName).append(',');
        if (!yName.isEmpty()) sb.append(yName).append(',');
        sb.append("ok,apogee_m,flight_time_s,meets_apogee,meets_time,error\n");
        int n = 0;
        for (Job.Row r : job.finishedRows()) {
            sb.append(n++).append(',').append(r.task().seed()).append(',');
            if (!xName.isEmpty()) sb.append(r.task().x()).append(',');
            if (!yName.isEmpty()) sb.append(r.task().y()).append(',');
            sb.append(r.ok()).append(',');
            if (r.ok()) {
                sb.append(r.apogeeM()).append(',').append(r.flightTimeS()).append(',')
                        .append(job.targets.meetsApogee(r.apogeeM())).append(',')
                        .append(job.targets.meetsTime(r.flightTimeS())).append(',');
            } else {
                sb.append(",,,,");
            }
            sb.append(csvText(r.error())).append('\n');
        }
        return sb.toString();
    }

    private static String csvText(String s) {
        if (s == null) return "";
        String t = s.replace("\"", "\"\"").replace('\n', ' ').replace('\r', ' ');
        // Spreadsheet formula injection guard: error text is server-generated but may echo file content.
        if (!t.isEmpty() && "=+-@".indexOf(t.charAt(0)) >= 0) t = "'" + t;
        return "\"" + t + "\"";
    }
}
