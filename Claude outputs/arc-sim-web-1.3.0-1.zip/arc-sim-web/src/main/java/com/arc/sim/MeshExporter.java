package com.arc.sim;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MeshExporter {

    private static final double MM_PER_M = 1000.0;
    private static final int REVOLUTION_SEGMENTS = 32;
    private static final double FIN_THICKNESS_M = 0.003;

    public static class Triangle {
        public final double[] n = new double[3];
        public final double[][] v = new double[3][3];

        Triangle(double[] a, double[] b, double[] c) {
            v[0] = a; v[1] = b; v[2] = c;
            computeNormal();
        }

        private void computeNormal() {
            double ux = v[1][0] - v[0][0], uy = v[1][1] - v[0][1], uz = v[1][2] - v[0][2];
            double wx = v[2][0] - v[0][0], wy = v[2][1] - v[0][1], wz = v[2][2] - v[0][2];
            double nx = uy * wz - uz * wy;
            double ny = uz * wx - ux * wz;
            double nz = ux * wy - uy * wx;
            double len = Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (len < 1e-12) { n[0] = 0; n[1] = 0; n[2] = 1; return; }
            n[0] = nx / len; n[1] = ny / len; n[2] = nz / len;
        }
    }

    /** Builds the mesh from whichever source the shared {@link MeshSource} setting selects. */
    public static List<Triangle> buildMesh(RocketGeometryExtractor.Geometry geo) {
        return buildMesh(geo, MeshSource.useCad());
    }

    /**
     * With preferCad, the bundled ARC V2 CAD model is used when the rocket is the ARC V2 airframe (fins are conformed
     * to the rocket's own fin set). Anything else falls back to the generated mesh, so the file always describes the
     * rocket that was loaded.
     */
    public static List<Triangle> buildMesh(RocketGeometryExtractor.Geometry geo, boolean preferCad) {
        if (preferCad) {
            String why = CadModel.get().mismatch(geo);
            if (why == null) return CadModel.get().buildMesh(geo);
            System.out.println("ARC V2 CAD model not used (" + why + "); exporting the generated mesh instead.");
        }
        return buildGeneratedMesh(geo);
    }

    /** The generated mesh as a flat triangle soup with per-triangle classes (airframe, fin, appendage), for viewers. */
    public static CadModel.Flat generatedFlat(RocketGeometryExtractor.Geometry geo) {
        List<Triangle> body = new ArrayList<>();
        for (RocketGeometryExtractor.BodyShape b : geo.bodies) addBodyOfRevolution(body, b);
        if (!geo.bodies.isEmpty()) {
            RocketGeometryExtractor.BodyShape last = geo.bodies.get(geo.bodies.size() - 1);
            addEndCap(body, last.xStart + last.length, last.aftRadius, false);
        }
        List<Triangle> fins = buildFinSetMesh(geo.fins, false);
        List<Triangle> other = new ArrayList<>();
        for (RocketGeometryExtractor.AppendageShape a : geo.appendages) addAppendage(other, a);
        int n = body.size() + fins.size() + other.size();
        float[] xyz = new float[n * 9];
        byte[] cls = new byte[n];
        int k = 0;
        List<List<Triangle>> groups = List.of(body, fins, other);
        byte[] classes = {CadModel.CLASS_AIRFRAME, CadModel.CLASS_FIN, CadModel.CLASS_INTERNAL};
        for (int g = 0; g < groups.size(); g++) {
            for (Triangle t : groups.get(g)) {
                for (int c = 0; c < 3; c++)
                    for (int d = 0; d < 3; d++) xyz[k * 9 + c * 3 + d] = (float) t.v[c][d];
                cls[k++] = classes[g];
            }
        }
        return new CadModel.Flat(xyz, cls);
    }

    public static List<Triangle> buildGeneratedMesh(RocketGeometryExtractor.Geometry geo) {
        List<Triangle> tris = new ArrayList<>();
        for (RocketGeometryExtractor.BodyShape body : geo.bodies) {
            addBodyOfRevolution(tris, body);
        }
        if (!geo.bodies.isEmpty()) {
            RocketGeometryExtractor.BodyShape lastBody = geo.bodies.get(geo.bodies.size() - 1);
            addEndCap(tris, lastBody.xStart + lastBody.length, lastBody.aftRadius, false);
        }
        for (RocketGeometryExtractor.FinShape fin : geo.fins) {
            addFinSet(tris, fin);
        }
        for (RocketGeometryExtractor.AppendageShape appendage : geo.appendages) {
            addAppendage(tris, appendage);
        }
        return tris;
    }

    private static void addAppendage(List<Triangle> tris, RocketGeometryExtractor.AppendageShape a) {
        double halfLen = Math.max(0.0015, a.lengthAlongAxis / 2.0);
        double halfWidth = halfLen;
        double rInner = a.parentRadius;
        double rOuter = a.parentRadius + Math.max(0.001, a.protrusionHeight);

        double x0 = (a.xCenter - halfLen) * MM_PER_M;
        double x1 = (a.xCenter + halfLen) * MM_PER_M;
        double yInner = rInner * MM_PER_M;
        double yOuter = rOuter * MM_PER_M;
        double z0 = -halfWidth * MM_PER_M;
        double z1 = halfWidth * MM_PER_M;

        double[] a000 = {x0, yInner, z0};
        double[] a100 = {x1, yInner, z0};
        double[] a110 = {x1, yInner, z1};
        double[] a010 = {x0, yInner, z1};
        double[] b000 = {x0, yOuter, z0};
        double[] b100 = {x1, yOuter, z0};
        double[] b110 = {x1, yOuter, z1};
        double[] b010 = {x0, yOuter, z1};

        addQuad(tris, b000, b100, b110, b010);
        addQuad(tris, a010, a110, a100, a000);
        addQuad(tris, a000, a100, b100, b000);
        addQuad(tris, a100, a110, b110, b100);
        addQuad(tris, a110, a010, b010, b110);
        addQuad(tris, a010, a000, b000, b010);
    }

    public static List<Triangle> buildFinSetMesh(List<RocketGeometryExtractor.FinShape> fins) {
        return buildFinSetMesh(fins, MeshSource.useCad());
    }

    /** CAD fins are the real airfoil sections, resized to the requested planform; generated fins are flat plates. */
    public static List<Triangle> buildFinSetMesh(List<RocketGeometryExtractor.FinShape> fins, boolean preferCad) {
        if (preferCad && !fins.isEmpty()) return CadModel.get().buildFinMesh(fins);
        List<Triangle> tris = new ArrayList<>();
        for (RocketGeometryExtractor.FinShape fin : fins) {
            addFinSet(tris, fin);
        }
        return tris;
    }

    private static double[] cyl(double x, double r, double theta) {
        return new double[]{x * MM_PER_M, r * Math.cos(theta) * MM_PER_M, r * Math.sin(theta) * MM_PER_M};
    }

    private static void addBodyOfRevolution(List<Triangle> tris, RocketGeometryExtractor.BodyShape body) {
        double[] profile = body.profileR;
        int stations = profile.length;
        double dTheta = 2 * Math.PI / REVOLUTION_SEGMENTS;
        double dx = body.length / (double) (stations - 1);

        for (int s = 0; s < stations - 1; s++) {
            double x0 = body.xStart + s * dx, x1 = body.xStart + (s + 1) * dx;
            double r0 = profile[s], r1 = profile[s + 1];

            for (int i = 0; i < REVOLUTION_SEGMENTS; i++) {
                double t0 = i * dTheta, t1 = (i + 1) * dTheta;

                if (r0 < 1e-9) {

                    double[] apex = cyl(x0, 0, 0);
                    double[] b0 = cyl(x1, r1, t0);
                    double[] b1 = cyl(x1, r1, t1);
                    tris.add(new Triangle(apex, b0, b1));
                } else if (r1 < 1e-9) {
                    double[] apex = cyl(x1, 0, 0);
                    double[] a0 = cyl(x0, r0, t0);
                    double[] a1 = cyl(x0, r0, t1);
                    tris.add(new Triangle(a0, a1, apex));
                } else {
                    double[] a0 = cyl(x0, r0, t0);
                    double[] a1 = cyl(x0, r0, t1);
                    double[] b0 = cyl(x1, r1, t0);
                    double[] b1 = cyl(x1, r1, t1);
                    tris.add(new Triangle(a0, a1, b1));
                    tris.add(new Triangle(a0, b1, b0));
                }
            }
        }
    }

    private static void addEndCap(List<Triangle> tris, double x, double radius, boolean facingNegativeX) {
        if (radius < 1e-9) return;
        double dTheta = 2 * Math.PI / REVOLUTION_SEGMENTS;
        double[] center = new double[]{x * MM_PER_M, 0, 0};
        for (int i = 0; i < REVOLUTION_SEGMENTS; i++) {
            double t0 = i * dTheta, t1 = (i + 1) * dTheta;
            double[] p0 = cyl(x, radius, t0);
            double[] p1 = cyl(x, radius, t1);
            if (facingNegativeX) {
                tris.add(new Triangle(center, p1, p0));
            } else {
                tris.add(new Triangle(center, p0, p1));
            }
        }
    }

    private static void addFinSet(List<Triangle> tris, RocketGeometryExtractor.FinShape fin) {
        double halfT = FIN_THICKNESS_M / 2.0;
        double dTheta = 2 * Math.PI / fin.finCount;

        double rootLeadX = fin.xStart, rootTrailX = fin.xStart + fin.rootChord;
        double tipLeadX = fin.xStart + fin.sweep, tipTrailX = fin.xStart + fin.sweep + fin.tipChord;
        double rBase = fin.parentRadius, rTip = fin.parentRadius + fin.height;

        for (int i = 0; i < fin.finCount; i++) {
            double theta = fin.baseRotationRad + i * dTheta;

            double radY = Math.cos(theta), radZ = Math.sin(theta);
            double tanY = -Math.sin(theta), tanZ = Math.cos(theta);

            double[] rl = {rootLeadX, rBase * radY, rBase * radZ};
            double[] rt = {rootTrailX, rBase * radY, rBase * radZ};
            double[] tt = {tipTrailX, rTip * radY, rTip * radZ};
            double[] tl = {tipLeadX, rTip * radY, rTip * radZ};

            double[][] plusFace = offsetQuad(rl, rt, tt, tl, tanY, tanZ, halfT);
            double[][] minusFace = offsetQuad(rl, rt, tt, tl, tanY, tanZ, -halfT);

            addQuad(tris, plusFace[0], plusFace[1], plusFace[2], plusFace[3]);
            addQuad(tris, minusFace[3], minusFace[2], minusFace[1], minusFace[0]);

            addQuad(tris, minusFace[0], minusFace[3], plusFace[3], plusFace[0]);
            addQuad(tris, plusFace[1], plusFace[2], minusFace[2], minusFace[1]);
            addQuad(tris, minusFace[3], minusFace[2], plusFace[2], plusFace[3]);
            addQuad(tris, plusFace[0], plusFace[1], minusFace[1], minusFace[0]);
        }
    }

    private static double[][] offsetQuad(double[] a, double[] b, double[] c, double[] d,
                                          double tanY, double tanZ, double t) {
        return new double[][]{
                offset(a, tanY, tanZ, t), offset(b, tanY, tanZ, t), offset(c, tanY, tanZ, t), offset(d, tanY, tanZ, t)
        };
    }

    private static double[] offset(double[] p, double tanY, double tanZ, double t) {

        return new double[]{p[0] * MM_PER_M, (p[1] + tanY * t) * MM_PER_M, (p[2] + tanZ * t) * MM_PER_M};
    }

    private static void addQuad(List<Triangle> tris, double[] a, double[] b, double[] c, double[] d) {
        tris.add(new Triangle(a, b, c));
        tris.add(new Triangle(a, c, d));
    }

    public static void writeStl(List<Triangle> tris, File out, String solidName) throws IOException {
        try (PrintWriter pw = new PrintWriter(out, StandardCharsets.UTF_8)) {
            pw.println("solid " + sanitize(solidName));
            for (Triangle t : tris) {
                pw.printf("facet normal %s %s %s%n", f(t.n[0]), f(t.n[1]), f(t.n[2]));
                pw.println("  outer loop");
                for (double[] v : t.v) {
                    pw.printf("    vertex %s %s %s%n", f(v[0]), f(v[1]), f(v[2]));
                }
                pw.println("  endloop");
                pw.println("endfacet");
            }
            pw.println("endsolid " + sanitize(solidName));
        }
    }

    public static void writeObj(List<Triangle> tris, File out, String objectName) throws IOException {
        try (PrintWriter pw = new PrintWriter(out, StandardCharsets.UTF_8)) {
            pw.println("# Exported by ARC Rocket Simulation Toolkit -- Geometry Exporter");
            pw.println("# Units millimeters; x runs from the nose tip aft");
            pw.println("o " + sanitize(objectName));
            int vIdx = 1;
            for (Triangle t : tris) {
                for (double[] v : t.v) {
                    pw.printf("v %s %s %s%n", f(v[0]), f(v[1]), f(v[2]));
                }
                pw.printf("f %d %d %d%n", vIdx, vIdx + 1, vIdx + 2);
                vIdx += 3;
            }
        }
    }

    private static String f(double d) {
        return String.format("%.5f", d);
    }

    private static String sanitize(String s) {
        return s == null ? "rocket" : s.replaceAll("[^A-Za-z0-9_.-]", "_");
    }
}

