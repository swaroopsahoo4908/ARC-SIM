package com.arc.sim.web;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Summary statistics over a sample of flight results. */
final class Stats {
    private Stats() {}

    static double mean(double[] v) {
        if (v.length == 0) return Double.NaN;
        double s = 0;
        for (double x : v) s += x;
        return s / v.length;
    }

    /** Sample standard deviation (n - 1), NaN below two samples. */
    static double sd(double[] v) {
        if (v.length < 2) return Double.NaN;
        double m = mean(v);
        double s = 0;
        for (double x : v) s += (x - m) * (x - m);
        return Math.sqrt(s / (v.length - 1));
    }

    /** Linear-interpolated percentile of an already sorted array, p in [0, 100]. */
    static double percentile(double[] sorted, double p) {
        if (sorted.length == 0) return Double.NaN;
        if (sorted.length == 1) return sorted[0];
        double pos = p / 100.0 * (sorted.length - 1);
        int lo = (int) Math.floor(pos);
        int hi = Math.min(lo + 1, sorted.length - 1);
        return sorted[lo] + (pos - lo) * (sorted[hi] - sorted[lo]);
    }

    /** Wilson score interval for a binomial proportion, 95%. Returns {low, high}. */
    static double[] wilson95(int successes, int n) {
        if (n == 0) return new double[]{Double.NaN, Double.NaN};
        double z = 1.96;
        double p = (double) successes / n;
        double denom = 1 + z * z / n;
        double centre = (p + z * z / (2.0 * n)) / denom;
        double half = z * Math.sqrt(p * (1 - p) / n + z * z / (4.0 * n * n)) / denom;
        return new double[]{Math.max(0, centre - half), Math.min(1, centre + half)};
    }

    static Map<String, Object> describe(double[] values) {
        double[] sorted = values.clone();
        Arrays.sort(sorted);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("n", values.length);
        m.put("mean", mean(values));
        m.put("sd", sd(values));
        m.put("sem", values.length < 2 ? Double.NaN : sd(values) / Math.sqrt(values.length));
        m.put("min", sorted.length == 0 ? Double.NaN : sorted[0]);
        m.put("p5", percentile(sorted, 5));
        m.put("p25", percentile(sorted, 25));
        m.put("p50", percentile(sorted, 50));
        m.put("p75", percentile(sorted, 75));
        m.put("p95", percentile(sorted, 95));
        m.put("max", sorted.length == 0 ? Double.NaN : sorted[sorted.length - 1]);
        return m;
    }

    /** Equal-width histogram. Returns {edges (bins + 1), counts (bins)} as a map. */
    static Map<String, Object> histogram(double[] values, int bins) {
        Map<String, Object> m = new LinkedHashMap<>();
        if (values.length == 0) {
            m.put("edges", new double[0]);
            m.put("counts", List.of());
            return m;
        }
        double lo = Double.POSITIVE_INFINITY;
        double hi = Double.NEGATIVE_INFINITY;
        for (double v : values) {
            lo = Math.min(lo, v);
            hi = Math.max(hi, v);
        }
        if (hi - lo < 1e-9) {
            hi = lo + 1e-3;
        }
        int[] counts = new int[bins];
        double width = (hi - lo) / bins;
        for (double v : values) {
            int b = (int) ((v - lo) / width);
            if (b >= bins) b = bins - 1;
            counts[b]++;
        }
        double[] edges = new double[bins + 1];
        for (int i = 0; i <= bins; i++) edges[i] = lo + i * width;
        java.util.ArrayList<Integer> c = new java.util.ArrayList<>();
        for (int x : counts) c.add(x);
        m.put("edges", edges);
        m.put("counts", c);
        return m;
    }
}
