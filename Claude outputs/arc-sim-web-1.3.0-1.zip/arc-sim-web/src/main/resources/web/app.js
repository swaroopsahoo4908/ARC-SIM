(() => {
'use strict';

const $ = (id) => document.getElementById(id);
const SVGNS = 'http://www.w3.org/2000/svg';
const FT_PER_M = 1 / 0.3048;
const SWEEP_DEFAULTS = {
  windAvg: [0, 20], turbulencePct: [0, 60], temp: [-10, 40], pressure: [970, 1030], rodAngle: [0, 6],
};

let cfg = null;
let key = sessionStorage.getItem('arcKey') || '';
let mode = 'single';
let pollTimer = null;
let currentId = null;
let lastStatus = null;
let secPerFlight = null;
const env = {};

// ---------- small DOM helpers (no innerHTML anywhere: rocket names come from uploaded files) ----------

function el(tag, props, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (k === 'class') n.className = v; else if (k === 'text') n.textContent = v; else n.setAttribute(k, v);
  }
  for (const c of kids) if (c != null) n.append(c);
  return n;
}
function sv(tag, attrs, ...kids) {
  const n = document.createElementNS(SVGNS, tag);
  for (const [k, v] of Object.entries(attrs || {})) n.setAttribute(k, v);
  for (const c of kids) if (c != null) n.append(c);
  return n;
}
function svgText(x, y, s, attrs) {
  const t = sv('text', Object.assign({ x, y }, attrs || {}));
  t.textContent = s;
  return t;
}
function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); }

const fmt = (x, d = 2) => (x == null || Number.isNaN(x)) ? '—' : Number(x).toFixed(d);
const pct = (x, d = 1) => (x == null) ? '—' : (x * 100).toFixed(d) + '%';
const ft = (m) => m * FT_PER_M;

async function api(path, opts = {}) {
  const headers = Object.assign({}, opts.headers || {});
  if (key) headers['X-Access-Key'] = key;
  const res = await fetch(path, Object.assign({}, opts, { headers }));
  if (opts.raw) {
    if (!res.ok) throw new Error('Request failed (' + res.status + ')');
    return res;
  }
  let body = null;
  try { body = await res.json(); } catch (e) { /* non-JSON error body */ }
  if (!res.ok) {
    const err = new Error((body && body.error) || ('Request failed (' + res.status + ')'));
    err.status = res.status;
    throw err;
  }
  return body;
}

function showError(msg) {
  const e = $('error');
  if (!msg) { e.hidden = true; return; }
  e.textContent = msg;
  e.hidden = false;
}

// ---------- setup ----------

async function init() {
  try {
    cfg = await api('/api/config');
  } catch (e) {
    showError('Could not reach the server: ' + e.message);
    return;
  }
  $('server-info').textContent = 'v' + cfg.version + ' · ' + cfg.threads + ' threads · max ' + cfg.maxSimsPerJob + ' flights/job';
  if (cfg.requiresKey) {
    $('key-box').hidden = false;
    $('key').value = key;
    $('key').addEventListener('change', () => {
      key = $('key').value.trim();
      sessionStorage.setItem('arcKey', key);
      loadRockets();
    });
  }
  if (cfg.allowUpload) {
    $('upload-box').hidden = false;
    $('max-upload').textContent = cfg.maxUploadMb;
  }
  if (/^https?:\/\//.test(cfg.sourceUrl || '')) {
    const a = el('a', { href: cfg.sourceUrl, rel: 'noopener', text: 'Source code (AGPL-3.0)' });
    $('source-link').append(a);
  }

  buildEnvFields();
  buildSites();
  buildSweepSelects();
  const t = cfg.targets;
  $('t-apogee').value = t.apogeeM;
  $('t-apogee-tol').value = t.apogeeTolM;
  $('t-time').value = t.timeS;
  $('t-time-tol').value = t.timeTolS;

  document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => setMode(b.dataset.mode)));
  $('run').addEventListener('click', run);
  $('cancel').addEventListener('click', cancel);
  $('upload').addEventListener('change', upload);
  $('rocket').addEventListener('change', () => { showRocketInfo(); loadMesh(); });
  $('cad-toggle').addEventListener('change', loadMesh);
  initViewer();
  $('site').addEventListener('change', () => { $('custom-site').hidden = $('site').value !== 'CUSTOM'; });
  for (const id of ['runs', 'spp', 'ax-pts', 'ay-pts', 'ay-param', 'ax-param']) {
    $(id).addEventListener('input', updateBudget);
  }
  await loadRockets();
  updateBudget();
  health();
  setInterval(health, 15000);
}

async function health() {
  try {
    await api('/api/health');
    $('health').className = 'dot ok';
  } catch (e) {
    $('health').className = 'dot bad';
  }
}

let rocketList = [];
async function loadRockets() {
  try {
    rocketList = (await api('/api/rockets')).rockets;
    showError('');
  } catch (e) {
    if (e.status === 401) { showError('This server needs an access key. Enter it in the panel on the left.'); }
    else showError(e.message);
    return;
  }
  const sel = $('rocket');
  const keep = sel.value;
  clear(sel);
  for (const r of rocketList) sel.append(el('option', { value: r.id, text: r.label }));
  if (keep && rocketList.some((r) => r.id === keep)) sel.value = keep;
  showRocketInfo();
  loadMesh();
}

function showRocketInfo() {
  const r = rocketList.find((x) => x.id === $('rocket').value);
  if (!r) { $('rocket-info').textContent = ''; return; }
  $('rocket-info').textContent = (r.rocketName || r.label) + ' · ' + r.stages + ' stage' + (r.stages === 1 ? '' : 's')
    + ' · still-air apogee ' + fmt(r.baselineApogeeM, 1) + ' m (' + fmt(ft(r.baselineApogeeM), 0) + ' ft)';
}

async function upload() {
  const f = $('upload').files[0];
  if (!f) return;
  showError('');
  try {
    const buf = await f.arrayBuffer();
    const r = await api('/api/rockets', { method: 'POST', body: buf, headers: { 'X-Filename': f.name, 'Content-Type': 'application/octet-stream' } });
    await loadRockets();
    $('rocket').value = r.id;
    showRocketInfo();
  } catch (e) {
    showError(e.message);
  }
  $('upload').value = '';
}

function buildEnvFields() {
  const host = $('env-fields');
  for (const p of cfg.params) {
    env[p.id] = p.default;
    const range = el('input', { type: 'range', min: p.min, max: p.max, step: stepFor(p), value: p.default, 'aria-label': p.label });
    const num = el('input', { type: 'number', min: p.min, max: p.max, step: stepFor(p), value: p.default, 'aria-label': p.label + ' value' });
    range.addEventListener('input', () => { num.value = range.value; env[p.id] = Number(range.value); });
    num.addEventListener('input', () => {
      const v = Number(num.value);
      if (!Number.isNaN(v)) { range.value = v; env[p.id] = v; }
    });
    host.append(el('div', { class: 'env-row' }, el('span', { class: 'name', text: p.label }), el('span'), range, num));
  }
}
function stepFor(p) { return (p.max - p.min) > 200 ? 1 : (p.max - p.min) > 30 ? 0.5 : 0.1; }

function buildSites() {
  const s = $('site');
  for (const x of cfg.sites) s.append(el('option', { value: x.id, text: x.label + ' (' + x.altM + ' m)' }));
  s.append(el('option', { value: 'CUSTOM', text: 'Custom coordinates' }));
}

function buildSweepSelects() {
  const x = $('ax-param'); const y = $('ay-param');
  y.append(el('option', { value: '', text: 'none (1-D sweep)' }));
  for (const p of cfg.params) {
    x.append(el('option', { value: p.id, text: p.label }));
    y.append(el('option', { value: p.id, text: p.label }));
  }
  x.value = 'windAvg';
  y.value = 'temp';
  const setRange = (sel, mn, mx) => () => {
    const d = SWEEP_DEFAULTS[sel.value];
    if (d) { $(mn).value = d[0]; $(mx).value = d[1]; }
    $('ay-fields').style.opacity = $('ay-param').value ? '1' : '.4';
    updateBudget();
  };
  x.addEventListener('change', setRange(x, 'ax-min', 'ax-max'));
  y.addEventListener('change', setRange(y, 'ay-min', 'ay-max'));
  setRange(x, 'ax-min', 'ax-max')();
  setRange(y, 'ay-min', 'ay-max')();
}

function setMode(m) {
  mode = m;
  document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('on', b.dataset.mode === m));
  for (const k of ['single', 'ensemble', 'sweep']) $('mode-' + k).hidden = k !== m;
  updateBudget();
}

function flightCount() {
  if (mode === 'single') return 1;
  if (mode === 'ensemble') return Math.max(0, Math.floor(Number($('runs').value) || 0));
  const nx = Math.max(1, Math.floor(Number($('ax-pts').value) || 1));
  const ny = $('ay-param').value ? Math.max(1, Math.floor(Number($('ay-pts').value) || 1)) : 1;
  return nx * ny * Math.max(1, Math.floor(Number($('spp').value) || 1));
}

function updateBudget() {
  const n = flightCount();
  const over = n > cfg.maxSimsPerJob;
  let t = n + ' flight' + (n === 1 ? '' : 's');
  if (secPerFlight) t += ' · about ' + fmtDuration(n * secPerFlight) + ' based on your last run';
  if (over) t = n + ' flights is over the limit of ' + cfg.maxSimsPerJob + ' for this server.';
  $('budget').textContent = t;
  $('run').disabled = over || n < 1;
}

function fmtDuration(s) {
  if (s < 90) return Math.max(1, Math.round(s)) + ' s';
  if (s < 5400) return Math.round(s / 60) + ' min';
  return (s / 3600).toFixed(1) + ' h';
}

// ---------- running a job ----------

function readRequest() {
  const num = (id) => Number($(id).value);
  const body = {
    rocket: $('rocket').value,
    mode,
    env: Object.assign({}, env, { site: $('site').value }),
    targets: {
      apogeeM: num('t-apogee'), apogeeTolM: num('t-apogee-tol'),
      timeS: num('t-time'), timeTolS: num('t-time-tol'),
    },
    baseSeed: Math.max(0, Math.floor(num('seed') || 1)),
  };
  if ($('site').value === 'CUSTOM') {
    Object.assign(body.env, { lat: num('lat'), lon: num('lon'), altM: num('alt') });
  }
  if (mode === 'ensemble') body.runs = Math.floor(num('runs'));
  if (mode === 'sweep') {
    body.axes = [{ param: $('ax-param').value, min: num('ax-min'), max: num('ax-max'), points: Math.floor(num('ax-pts')) }];
    if ($('ay-param').value) {
      body.axes.push({ param: $('ay-param').value, min: num('ay-min'), max: num('ay-max'), points: Math.floor(num('ay-pts')) });
    }
    body.seedsPerPoint = Math.floor(num('spp'));
  }
  return body;
}

async function run() {
  showError('');
  $('empty').hidden = true;
  $('out').hidden = true;
  try {
    const r = await api('/api/jobs', { method: 'POST', body: JSON.stringify(readRequest()), headers: { 'Content-Type': 'application/json' } });
    currentId = r.id;
    $('run').hidden = true;
    $('cancel').hidden = false;
    $('progress').hidden = false;
    setProgress(0, r.total, null, 'queued');
    poll();
  } catch (e) {
    showError(e.message);
    if (!lastStatus) $('empty').hidden = false;
  }
}

async function cancel() {
  if (!currentId) return;
  try { await api('/api/jobs/' + currentId, { method: 'DELETE' }); } catch (e) { showError(e.message); }
}

function setProgress(done, total, eta, state, queuePos) {
  $('bar-fill').style.width = (total ? (100 * done / total) : 0) + '%';
  let t = done + ' / ' + total + ' flights';
  if (state === 'queued') t = queuePos ? ('Waiting in queue, position ' + queuePos) : 'Starting';
  $('prog-text').textContent = t;
  $('prog-eta').textContent = eta != null ? ('about ' + fmtDuration(eta) + ' left') : '';
}

async function poll() {
  clearTimeout(pollTimer);
  let s;
  try {
    s = await api('/api/jobs/' + currentId);
  } catch (e) {
    finish();
    showError(e.message);
    return;
  }
  setProgress(s.done, s.total, s.etaS, s.state, s.queuePosition);
  if (s.state === 'queued' || s.state === 'running') {
    pollTimer = setTimeout(poll, 500);
    return;
  }
  finish();
  lastStatus = s;
  if (s.state === 'done') {
    if (s.total > 0 && s.elapsedS > 0) secPerFlight = s.elapsedS / s.total;
    updateBudget();
    render(s);
  } else if (s.state === 'cancelled') {
    showError('Run cancelled.');
  } else {
    showError('The run failed: ' + (s.error || 'unknown error'));
  }
}

function finish() {
  $('run').hidden = false;
  $('cancel').hidden = true;
  $('progress').hidden = true;
}

// ---------- results ----------

function card(k, v, s, cls) {
  return el('div', { class: 'card' }, el('div', { class: 'k', text: k }),
    el('div', { class: 'v' + (cls ? ' ' + cls : ''), text: v }), s ? el('div', { class: 's', text: s }) : null);
}

function render(s) {
  const out = $('out');
  clear(out);
  out.hidden = false;
  const r = s.result;
  out.append(el('p', { class: 'note', text: s.rocket.label + ' · ' + s.mode + ' · ' + s.total + ' flight' + (s.total === 1 ? '' : 's') + ' in ' + fmt(s.elapsedS, 1) + ' s' }));
  if (r.mode === 'single') renderSingle(out, r);
  else if (r.mode === 'ensemble') renderEnsemble(out, r);
  else renderSweep(out, r);
  const csv = el('button', { class: 'ghost', text: 'Download CSV' });
  csv.addEventListener('click', downloadCsv);
  out.append(el('div', { class: 'actions' }, csv));
}

async function downloadCsv() {
  try {
    const res = await api('/api/jobs/' + currentId + '/csv', { raw: true });
    const blob = await res.blob();
    const a = el('a', { href: URL.createObjectURL(blob), download: 'arc-sim-' + currentId + '.csv' });
    document.body.append(a);
    a.click();
    a.remove();
  } catch (e) { showError(e.message); }
}

function renderSingle(out, r) {
  if (!r.ok) { showError('The flight failed: ' + r.error); return; }
  const t = r.targets;
  const cards = el('div', { class: 'cards' });
  cards.append(card('Apogee', fmt(r.apogeeM, 2) + ' m', fmt(ft(r.apogeeM), 0) + ' ft'));
  cards.append(card('Versus target', (r.apogeeErrorM >= 0 ? '+' : '') + fmt(r.apogeeErrorM, 2) + ' m',
    'target ' + fmt(t.apogeeM, 2) + ' ± ' + fmt(t.apogeeTolM, 2) + ' m', r.meetsApogee ? 'good' : 'bad'));
  cards.append(card('Flight time', fmt(r.flightTimeS, 2) + ' s',
    'target ' + fmt(t.timeS, 1) + ' ± ' + fmt(t.timeTolS, 1) + ' s', r.meetsTime ? 'good' : 'bad'));
  cards.append(card('Seed', String(r.seed), 'same seed, same flight'));
  out.append(cards);
  out.append(el('p', { class: 'note', text: 'One gust pattern is one draw from a wide spread. Run a gust ensemble before trusting a pass or fail at these conditions.' }));
}

function renderEnsemble(out, r) {
  const a = r.apogee; const t = r.targets;
  const cards = el('div', { class: 'cards' });
  cards.append(card('Mean apogee', fmt(a.mean, 2) + ' m', '± ' + fmt(a.sd, 2) + ' m (1 sd), n = ' + a.n));
  cards.append(card('5–95% range', fmt(a.p5, 0) + '–' + fmt(a.p95, 0) + ' m', 'median ' + fmt(a.p50, 2) + ' m'));
  cards.append(card('Apogee in band', pct(r.pApogee), '± ' + fmt(t.apogeeTolM, 2) + ' m of ' + fmt(t.apogeeM, 2) + ' m', rateClass(r.pApogee)));
  cards.append(card('Time in band', pct(r.pTime), '± ' + fmt(t.timeTolS, 1) + ' s of ' + fmt(t.timeS, 1) + ' s', rateClass(r.pTime)));
  const ci = r.pBothCi95;
  cards.append(card('Both in band', pct(r.pBoth), '95% CI ' + pct(ci[0], 0) + ' – ' + pct(ci[1], 0), rateClass(r.pBoth)));
  if (r.failed) cards.append(card('Failed flights', String(r.failed), 'left out of the statistics', 'warn'));
  out.append(cards);

  out.append(el('div', { class: 'chart-title' }, el('h3', { text: 'Apogee distribution' }),
    el('span', { class: 'muted', text: 'shaded = target band, dashed = mean' })));
  out.append(histogramChart(r));
  if (a.sd > t.apogeeTolM) {
    out.append(el('p', { class: 'note', text: 'Gusts alone move apogee by ' + fmt(a.sd, 2) + ' m (1 sd), which is wider than the ± ' + fmt(t.apogeeTolM, 2) + ' m band. Even a perfectly tuned design only lands in the band part of the time at these conditions.' }));
  }
}

function rateClass(p) { return p == null ? '' : p >= 0.8 ? 'good' : p >= 0.4 ? 'warn' : 'bad'; }

function niceTicks(lo, hi, n) {
  if (hi - lo < 1e-12) return [lo];
  const raw = (hi - lo) / n;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  const step = (norm < 1.5 ? 1 : norm < 3 ? 2 : norm < 7 ? 5 : 10) * mag;
  const out = [];
  for (let v = Math.ceil(lo / step) * step; v <= hi + step * 1e-9; v += step) out.push(Number(v.toPrecision(12)));
  return out;
}

function chartFrame(w, h) {
  return sv('svg', { viewBox: '0 0 ' + w + ' ' + h, class: 'chart', role: 'img', preserveAspectRatio: 'xMidYMid meet' });
}

function histogramChart(r) {
  const W = 760, H = 280, L = 48, R = 16, T = 14, B = 36;
  const svg = chartFrame(W, H);
  const edges = r.histogram.edges; const counts = r.histogram.counts;
  if (!counts.length) return svg;
  const t = r.targets;
  const lo = Math.min(edges[0], t.apogeeM - t.apogeeTolM);
  const hi = Math.max(edges[edges.length - 1], t.apogeeM + t.apogeeTolM);
  const x = (v) => L + (v - lo) / (hi - lo) * (W - L - R);
  const maxC = Math.max(...counts, 1);
  const y = (c) => H - B - c / maxC * (H - B - T);
  for (const tk of niceTicks(0, maxC, 4)) {
    svg.append(sv('line', { x1: L, x2: W - R, y1: y(tk), y2: y(tk), class: 'grid-line' }));
    svg.append(svgText(L - 6, y(tk) + 3, String(tk), { 'text-anchor': 'end' }));
  }
  svg.append(sv('rect', { x: x(t.apogeeM - t.apogeeTolM), width: Math.max(1.5, x(t.apogeeM + t.apogeeTolM) - x(t.apogeeM - t.apogeeTolM)), y: T, height: H - B - T, fill: '#4cc38a', opacity: '.22' }));
  for (let i = 0; i < counts.length; i++) {
    const bar = sv('rect', { x: x(edges[i]) + 0.5, width: Math.max(1, x(edges[i + 1]) - x(edges[i]) - 1), y: y(counts[i]), height: H - B - y(counts[i]), fill: '#f0a63a' });
    bar.append(sv('title', {}, document.createTextNode(fmt(edges[i], 2) + ' – ' + fmt(edges[i + 1], 2) + ' m: ' + counts[i] + ' flights')));
    svg.append(bar);
  }
  svg.append(sv('line', { x1: L, x2: W - R, y1: H - B, y2: H - B, class: 'axis-line' }));
  for (const tk of niceTicks(lo, hi, 7)) {
    svg.append(svgText(x(tk), H - B + 14, fmt(tk, 1), { 'text-anchor': 'middle' }));
  }
  svg.append(svgText((L + W - R) / 2, H - 4, 'Apogee (m)', { 'text-anchor': 'middle' }));
  svg.append(sv('line', { x1: x(r.apogee.mean), x2: x(r.apogee.mean), y1: T, y2: H - B, stroke: '#d9e0e8', 'stroke-dasharray': '4 3' }));
  return svg;
}

// ---------- sweeps ----------

const METRICS = {
  apogee: { label: 'Mean apogee', unit: 'm', get: (c) => c.meanApogeeM, kind: 'div', center: (t) => t.apogeeM },
  time: { label: 'Mean flight time', unit: 's', get: (c) => c.meanFlightTimeS, kind: 'div', center: (t) => t.timeS },
  pBoth: { label: 'P(both in band)', unit: '', get: (c) => c.pBoth, kind: 'seq', fixed: [0, 1] },
  sd: { label: 'Apogee spread (sd)', unit: 'm', get: (c) => c.sdApogeeM, kind: 'seq' },
};
let sweepMetric = 'apogee';

function renderSweep(out, r) {
  const t = r.targets;
  const best = r.best;
  const cards = el('div', { class: 'cards' });
  const ax = r.axes;
  cards.append(card('Grid', ax.map((a) => a.points).join(' × ') + ' points', r.seedsPerPoint + ' seed' + (r.seedsPerPoint === 1 ? '' : 's') + ' per point'));
  if (best) {
    let where = ax[0].label + ' = ' + fmt(best.x, 2);
    if (ax.length > 1) where += ', ' + ax[1].label + ' = ' + fmt(best.y, 2);
    cards.append(card('Best point', pct(best.pBoth, 0) + ' pass', where + ' · apogee ' + fmt(best.meanApogeeM, 2) + ' m', rateClass(best.pBoth)));
  }
  if (r.failed) cards.append(card('Failed flights', String(r.failed), 'left out', 'warn'));
  out.append(cards);

  const metricRow = el('div', { class: 'metric' });
  const holder = el('div');
  const keys = Object.keys(METRICS).filter((k) => k !== 'sd' || r.seedsPerPoint > 1);
  if (!keys.includes(sweepMetric)) sweepMetric = 'apogee';
  const draw = () => {
    clear(holder);
    for (const b of metricRow.children) b.classList.toggle('on', b.dataset.k === sweepMetric);
    holder.append(ax.length === 1 ? sweepLine(r, METRICS[sweepMetric]) : sweepHeat(r, METRICS[sweepMetric]));
  };
  for (const k of keys) {
    const b = el('button', { 'data-k': k, text: METRICS[k].label });
    b.addEventListener('click', () => { sweepMetric = k; draw(); });
    metricRow.append(b);
  }
  out.append(metricRow, holder);
  draw();
  if (r.seedsPerPoint === 1) {
    out.append(el('p', { class: 'note', text: 'Each point uses a single gust pattern, so neighbouring points differ partly by luck. Raise seeds per point to average that out.' }));
  }
}

function sweepLine(r, m) {
  const W = 760, H = 320, L = 56, R = 18, T = 16, B = 40;
  const svg = chartFrame(W, H);
  const a = r.axes[0];
  const cells = r.cells;
  const xs = cells.map((c) => c.x);
  const ys = cells.map((c) => m.get(c));
  const sds = m === METRICS.apogee ? cells.map((c) => c.sdApogeeM) : null;
  let lo = Infinity, hi = -Infinity;
  ys.forEach((v, i) => {
    if (v == null) return;
    const e = sds && sds[i] != null ? sds[i] : 0;
    lo = Math.min(lo, v - e); hi = Math.max(hi, v + e);
  });
  const center = m.center ? m.center(r.targets) : null;
  if (center != null) { lo = Math.min(lo, center); hi = Math.max(hi, center); }
  if (m.fixed) { lo = m.fixed[0]; hi = m.fixed[1]; }
  if (!(hi > lo)) { hi = lo + 1; }
  const pad = (hi - lo) * 0.06;
  lo -= pad; hi += pad;
  const xmin = Math.min(...xs), xmax = Math.max(...xs);
  const X = (v) => L + (xmax === xmin ? 0.5 : (v - xmin) / (xmax - xmin)) * (W - L - R);
  const Y = (v) => H - B - (v - lo) / (hi - lo) * (H - B - T);
  for (const tk of niceTicks(lo, hi, 6)) {
    svg.append(sv('line', { x1: L, x2: W - R, y1: Y(tk), y2: Y(tk), class: 'grid-line' }));
    svg.append(svgText(L - 6, Y(tk) + 3, fmt(tk, m.fixed ? 1 : 1), { 'text-anchor': 'end' }));
  }
  if (m === METRICS.apogee || m === METRICS.time) {
    const tol = m === METRICS.apogee ? r.targets.apogeeTolM : r.targets.timeTolS;
    svg.append(sv('rect', { x: L, width: W - L - R, y: Y(center + tol), height: Math.max(1.5, Y(center - tol) - Y(center + tol)), fill: '#4cc38a', opacity: '.22' }));
    svg.append(sv('line', { x1: L, x2: W - R, y1: Y(center), y2: Y(center), stroke: '#4cc38a', 'stroke-dasharray': '4 3' }));
  }
  svg.append(sv('line', { x1: L, x2: W - R, y1: H - B, y2: H - B, class: 'axis-line' }));
  for (const tk of niceTicks(xmin, xmax, 8)) svg.append(svgText(X(tk), H - B + 14, fmt(tk, 1), { 'text-anchor': 'middle' }));
  svg.append(svgText((L + W - R) / 2, H - 6, a.label, { 'text-anchor': 'middle' }));
  svg.append(svgText(12, 12, m.label + (m.unit ? ' (' + m.unit + ')' : ''), {}));
  let d = '';
  xs.forEach((x, i) => { if (ys[i] != null) d += (d ? 'L' : 'M') + X(x).toFixed(1) + ' ' + Y(ys[i]).toFixed(1); });
  svg.append(sv('path', { d, fill: 'none', stroke: '#f0a63a', 'stroke-width': 1.8 }));
  cells.forEach((c, i) => {
    if (ys[i] == null) return;
    if (sds && sds[i] != null && sds[i] > 0) {
      svg.append(sv('line', { x1: X(xs[i]), x2: X(xs[i]), y1: Y(ys[i] - sds[i]), y2: Y(ys[i] + sds[i]), stroke: '#f0a63a', opacity: '.5' }));
    }
    const dot = sv('circle', { cx: X(xs[i]), cy: Y(ys[i]), r: 3.4, fill: '#f0a63a' });
    dot.append(sv('title', {}, document.createTextNode(cellText(r, c))));
    svg.append(dot);
  });
  return svg;
}

function cellText(r, c) {
  const ax = r.axes;
  let s = ax[0].label + ': ' + fmt(c.x, 2);
  if (ax.length > 1) s += '\n' + ax[1].label + ': ' + fmt(c.y, 2);
  s += '\nmean apogee: ' + fmt(c.meanApogeeM, 2) + ' m';
  if (c.sdApogeeM != null) s += ' (sd ' + fmt(c.sdApogeeM, 2) + ')';
  s += '\nflight time: ' + fmt(c.meanFlightTimeS, 2) + ' s';
  s += '\nboth in band: ' + pct(c.pBoth, 0) + ' of ' + c.n;
  return s;
}

const lerp = (a, b, t) => a + (b - a) * t;
function mix(c1, c2, t) { return [lerp(c1[0], c2[0], t), lerp(c1[1], c2[1], t), lerp(c1[2], c2[2], t)]; }
function rgb(c) { return 'rgb(' + c.map((x) => Math.round(x)).join(',') + ')'; }
const BLUE = [74, 144, 217], WHITE = [232, 237, 242], ORANGE = [232, 116, 59], DARK = [27, 37, 49], GREEN = [76, 195, 138], AMBER = [240, 166, 58];

function colorFor(m, v, lo, hi) {
  if (v == null) return '#222c38';
  if (m.kind === 'div') {
    const c = m.centerVal;
    const t = v < c ? -(c - v) / Math.max(1e-9, c - Math.min(lo, c)) : (v - c) / Math.max(1e-9, Math.max(hi, c) - c);
    const k = Math.max(-1, Math.min(1, t));
    return rgb(k < 0 ? mix(WHITE, BLUE, -k) : mix(WHITE, ORANGE, k));
  }
  const t = hi > lo ? (v - lo) / (hi - lo) : 0;
  return rgb(mix(DARK, m === METRICS.pBoth ? GREEN : AMBER, Math.max(0, Math.min(1, t))));
}

function sweepHeat(r, m) {
  const W = 760, L = 64, R = 110, T = 26, B = 44;
  const nx = r.axes[0].points, ny = r.axes[1].points;
  const cw = Math.min(46, (W - L - R) / nx);
  const ch = Math.min(34, 360 / ny);
  const H = T + ch * ny + B;
  const svg = chartFrame(W, H);
  const vals = r.cells.map((c) => m.get(c)).filter((v) => v != null);
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (m.fixed) { lo = m.fixed[0]; hi = m.fixed[1]; }
  const mm = Object.assign({}, m);
  if (m.kind === 'div') mm.centerVal = m.center(r.targets);
  const ax = r.axes[0], ay = r.axes[1];
  r.cells.forEach((c) => {
    const rect = sv('rect', { x: L + c.ix * cw, y: T + (ny - 1 - c.iy) * ch, width: cw - 1, height: ch - 1, fill: colorFor(mm.kind === 'div' ? mm : m, m.get(c), lo, hi) });
    rect.append(sv('title', {}, document.createTextNode(cellText(r, c))));
    svg.append(rect);
  });
  const stepX = Math.max(1, Math.ceil(nx / 10)), stepY = Math.max(1, Math.ceil(ny / 8));
  for (let i = 0; i < nx; i += stepX) svg.append(svgText(L + i * cw + cw / 2, T + ch * ny + 14, fmt(ax.values[i], 1), { 'text-anchor': 'middle' }));
  for (let j = 0; j < ny; j += stepY) svg.append(svgText(L - 6, T + (ny - 1 - j) * ch + ch / 2 + 3, fmt(ay.values[j], 1), { 'text-anchor': 'end' }));
  svg.append(svgText(L + cw * nx / 2, H - 6, ax.label, { 'text-anchor': 'middle' }));
  svg.append(svgText(L, 14, ay.label + ' (vertical)', {}));
  // legend: top of the bar is the largest value shown, bottom the smallest, target marked in the middle of a diverging scale
  const lx = L + cw * nx + 22, ly = T, lh = Math.min(160, ch * ny);
  const top = m.kind === 'div' ? Math.max(hi, mm.centerVal) : hi;
  const bot = m.kind === 'div' ? Math.min(lo, mm.centerVal) : lo;
  for (let i = 0; i < 40; i++) {
    const v = top - (top - bot) * i / 39;
    svg.append(sv('rect', { x: lx, y: ly + i * lh / 40, width: 12, height: lh / 40 + 0.5, fill: colorFor(mm.kind === 'div' ? mm : m, v, lo, hi) }));
  }
  const unit = m.unit ? ' ' + m.unit : '';
  const dd = m.fixed ? 2 : 1;
  svg.append(svgText(lx + 18, ly + 8, fmt(top, dd) + unit, {}));
  svg.append(svgText(lx + 18, ly + lh, fmt(bot, dd) + unit, {}));
  if (m.kind === 'div' && top > mm.centerVal && bot < mm.centerVal) {
    const yy = ly + lh * (top - mm.centerVal) / (top - bot);
    svg.append(sv('line', { x1: lx - 3, x2: lx + 15, y1: yy, y2: yy, stroke: '#d9e0e8' }));
    svg.append(svgText(lx + 18, yy + 3, 'target ' + fmt(mm.centerVal, 1), {}));
  } else if (m.kind === 'div') {
    svg.append(svgText(lx + 18, ly + lh / 2, top === mm.centerVal ? 'target is at the top' : 'target is at the bottom', {}));
  }
  return svg;
}

init();
// ---- Rocket view: software-rendered 3D (no WebGL), flat-shaded triangles, back faces culled ----
const view = { tri: null, cls: null, n: 0, roll: 0.55, tilt: 0.30, zoom: 1, step: 1, pending: 0, drag: null };
const LENGTH_MM = 735;
let meshToken = 0;

async function loadMesh() {
  const id = $('rocket').value;
  if (!id) return;
  const token = ++meshToken;
  const wantCad = $('cad-toggle').checked;
  try {
    const res = await api('/api/rockets/' + encodeURIComponent(id) + '/mesh?source=' + (wantCad ? 'cad' : 'generated'), { raw: true });
    const buf = await res.arrayBuffer();
    if (token !== meshToken) return;
    const n = new DataView(buf).getUint32(0, true);
    view.n = n;
    view.tri = new Float32Array(buf, 4, n * 9);
    view.cls = new Uint8Array(buf, 4 + n * 36, n);
    $('view-note').textContent = (res.headers.get('X-Mesh-Note') || '') + ' · ' + n.toLocaleString() + ' triangles · drag to rotate, wheel to zoom, double-click to reset';
  } catch (e) {
    if (token !== meshToken) return;
    view.tri = null;
    $('view-note').textContent = 'Could not load the rocket view: ' + e.message;
  }
  drawView();
}

function initViewer() {
  const c = $('view');
  c.addEventListener('pointerdown', (e) => { c.setPointerCapture(e.pointerId); view.drag = { x: e.clientX, y: e.clientY }; view.step = view.n > 30000 ? 3 : 1; });
  c.addEventListener('pointermove', (e) => {
    if (!view.drag) return;
    view.roll += (e.clientX - view.drag.x) * 0.012;
    view.tilt = Math.max(-1.4, Math.min(1.4, view.tilt + (e.clientY - view.drag.y) * 0.012));
    view.drag = { x: e.clientX, y: e.clientY };
    scheduleDraw();
  });
  const end = () => { if (view.drag) { view.drag = null; view.step = 1; scheduleDraw(); } };
  c.addEventListener('pointerup', end);
  c.addEventListener('pointercancel', end);
  c.addEventListener('dblclick', () => { view.roll = 0.55; view.tilt = 0.30; view.zoom = 1; drawView(); });
  c.addEventListener('wheel', (e) => {
    e.preventDefault();
    view.zoom = Math.max(0.4, Math.min(6, view.zoom * Math.pow(1.1, -Math.sign(e.deltaY))));
    scheduleDraw();
  }, { passive: false });
  window.addEventListener('resize', scheduleDraw);
}

function scheduleDraw() {
  if (view.pending) return;
  view.pending = requestAnimationFrame(() => { view.pending = 0; drawView(); });
}

function drawView() {
  const c = $('view');
  const dpr = window.devicePixelRatio || 1;
  const w = Math.max(200, Math.round(c.clientWidth * dpr)), h = Math.round(c.clientHeight * dpr);
  if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
  const g = c.getContext('2d');
  g.clearRect(0, 0, w, h);
  if (!view.tri) return;
  const T = view.tri, K = view.cls, n = view.n, step = view.step;
  const cr = Math.cos(view.roll), sr = Math.sin(view.roll), ct = Math.cos(view.tilt), st = Math.sin(view.tilt);
  const scale = Math.min(w / (LENGTH_MM * 1.05), h / 175) * view.zoom;
  const cx = w / 2, cy = h / 2, xc = LENGTH_MM / 2;
  const px = new Float32Array(n * 3), py = new Float32Array(n * 3), shade = new Float32Array(n);
  const keys = new Float64Array(n);
  let m = 0;
  const sx = [0, 0, 0], sy = [0, 0, 0], sz = [0, 0, 0];
  for (let i = 0; i < n; i += step) {
    for (let k = 0; k < 3; k++) {
      const x = T[i * 9 + k * 3] - xc, y = T[i * 9 + k * 3 + 1], z = T[i * 9 + k * 3 + 2];
      const y1 = y * cr - z * sr, z1 = y * sr + z * cr;
      sx[k] = x * ct + z1 * st; sz[k] = -x * st + z1 * ct; sy[k] = y1;
    }
    const ux = sx[1] - sx[0], uy = sy[1] - sy[0], uz = sz[1] - sz[0];
    const vx = sx[2] - sx[0], vy = sy[2] - sy[0], vz = sz[2] - sz[0];
    const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
    if (len < 1e-12 || nz <= 0) continue;
    shade[i] = 0.32 + 0.68 * Math.max(0, (-0.35 * nx + 0.55 * ny + 0.76 * nz) / len);
    for (let k = 0; k < 3; k++) { px[i * 3 + k] = cx + sx[k] * scale; py[i * 3 + k] = cy - sy[k] * scale; }
    keys[m++] = Math.floor((((sz[0] + sz[1] + sz[2]) / 3) + 2000) * 1000) * 16777216 + i;
  }
  const order = keys.subarray(0, m);
  order.sort();
  const base = [[196, 206, 222], [236, 150, 70], [128, 134, 144]];
  for (let j = 0; j < m; j++) {
    const key = order[j];
    const i = key - Math.floor(key / 16777216) * 16777216;
    const b = base[K[i]] || base[0], s = shade[i];
    g.fillStyle = 'rgb(' + Math.min(255, b[0] * s | 0) + ',' + Math.min(255, b[1] * s | 0) + ',' + Math.min(255, b[2] * s | 0) + ')';
    g.beginPath();
    g.moveTo(px[i * 3], py[i * 3]); g.lineTo(px[i * 3 + 1], py[i * 3 + 1]); g.lineTo(px[i * 3 + 2], py[i * 3 + 2]);
    g.closePath(); g.fill();
  }
}

})();
