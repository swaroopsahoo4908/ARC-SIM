#!/bin/bash
# ARC-SIM Web on this Mac, optionally shared through a free Cloudflare quick tunnel.
#
#   bash run-on-mac.sh            start, and share if cloudflared is installed
#   bash run-on-mac.sh --local    start for this Mac only (http://localhost:8080)
#
# Needs Java 17+ and, the first time only, Maven (to build the jar).
# Sharing needs cloudflared:  brew install cloudflared   (no account required for quick tunnels)

cd "$(dirname "$0")" || exit 1

PORT="${PORT:-8080}"
JAR="target/arc-sim-web.jar"
MODE="share"
[ "$1" = "--local" ] && MODE="local"

have() { command -v "$1" >/dev/null 2>&1; }

if ! have java; then
  echo "Java 17 or newer is required. Install it with:  brew install openjdk@17"
  exit 1
fi
JAVA_MAJOR=$(java -version 2>&1 | grep -m1 ' version "' | sed -E 's/.*version "([0-9]+).*/\1/')
if [ -z "$JAVA_MAJOR" ] || [ "$JAVA_MAJOR" -lt 17 ]; then
  echo "Found Java $JAVA_MAJOR, but 17 or newer is required."
  exit 1
fi

if [ ! -f "$JAR" ]; then
  if ! have mvn; then
    echo "No $JAR yet and Maven is not installed. Install it with:  brew install maven"
    exit 1
  fi
  echo "Building the jar (first run only, about a minute)..."
  mvn -q -B -DskipTests package || { echo "Build failed."; exit 1; }
fi

# Access key: keep one across restarts so shared links keep working.
if [ -z "$ARC_SIM_ACCESS_KEY" ]; then
  if [ ! -f .access-key ]; then
    LC_ALL=C tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 24 > .access-key
    chmod 600 .access-key
  fi
  ARC_SIM_ACCESS_KEY=$(cat .access-key)
fi
export ARC_SIM_ACCESS_KEY

# Leave one core free so the Mac stays responsive.
CPUS=$(sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || echo 2)
THREADS=$(( CPUS > 1 ? CPUS - 1 : 1 ))
export ARC_SIM_THREADS="${ARC_SIM_THREADS:-$THREADS}"
export PORT
[ "$MODE" = "share" ] && export ARC_TRUST_PROXY=true

SERVER_PID=""
TUNNEL_PID=""
cleanup() {
  [ -n "$TUNNEL_PID" ] && kill "$TUNNEL_PID" 2>/dev/null
  [ -n "$SERVER_PID" ] && kill "$SERVER_PID" 2>/dev/null
}
trap cleanup EXIT INT TERM

java -Djava.awt.headless=true -jar "$JAR" > server.log 2>&1 &
SERVER_PID=$!

printf "Starting server"
UP=0
for _ in $(seq 1 90); do
  if curl -fs "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1; then UP=1; break; fi
  if ! kill -0 "$SERVER_PID" 2>/dev/null; then break; fi
  printf "."
  sleep 1
done
echo
if [ "$UP" -ne 1 ]; then
  echo "The server did not start. Last lines of server.log:"
  tail -n 15 server.log
  exit 1
fi

# Keep the Mac awake while the server runs (macOS only).
have caffeinate && { caffeinate -i -w "$SERVER_PID" & }

echo
echo "Running locally:  http://localhost:$PORT"
echo "Access key:       $ARC_SIM_ACCESS_KEY"
echo "Worker threads:   $ARC_SIM_THREADS"

if [ "$MODE" = "share" ]; then
  if have cloudflared; then
    cloudflared tunnel --no-autoupdate --url "http://localhost:$PORT" > tunnel.log 2>&1 &
    TUNNEL_PID=$!
    URL=""
    for _ in $(seq 1 30); do
      URL=$(grep -Eo 'https://[a-z0-9-]+\.trycloudflare\.com' tunnel.log | head -1)
      [ -n "$URL" ] && break
      sleep 1
    done
    if [ -n "$URL" ]; then
      echo
      echo "Public link:      $URL"
      echo "Send people the link and the access key. The link changes every time you restart."
    else
      echo "The tunnel did not report a link. See tunnel.log."
    fi
  else
    echo
    echo "cloudflared is not installed, so this is local only."
    echo "To share it:  brew install cloudflared   then run this script again."
  fi
fi

if [ -z "$ARC_SOURCE_URL" ] && [ "$MODE" = "share" ]; then
  echo
  echo "Note: ARC-SIM is AGPL-3.0. When others use it over the network, offer them the source."
  echo "Set ARC_SOURCE_URL to your repository URL before running and the page footer will link to it."
fi

echo
echo "Press Ctrl+C to stop."
wait "$SERVER_PID"
