# ARC-SIM Web

A browser front end and HTTP API for the ARC-SIM flight engine. It runs the same OpenRocket 24.12 core as the desktop app (RK4 integration, Barrowman aerodynamics, the same seeded multi-level wind model), packaged as one Docker image. Nothing here shares files with the Mac project.

Three kinds of run are available in the browser:

- Single: one flight at chosen conditions. A seed fixes the gust pattern, so the same seed always gives the same apogee.
- Gust ensemble: the same conditions flown with many independent gust patterns. Reports mean, spread, 5th to 95th percentile, a histogram, and the fraction of flights landing inside the apogee and flight-time bands, with a 95% Wilson interval.
- Sweep: one or two conditions varied across a range (wind, turbulence, temperature, pressure, rod angle), optionally with several seeds per point. One axis draws a line chart, two draw a heat map. Every run can be downloaded as CSV.

## Quick start

You need Docker. From this folder:

```
docker compose up --build
```

Then open http://localhost:8080. The image build compiles the code and runs the test suite (about 30 s of real simulations). To skip the tests, build with `docker build --build-arg SKIP_TESTS=true -t arc-sim-web .`.

Without Docker, with JDK 17 or newer and Maven:

```
mvn package
java -jar target/arc-sim-web.jar
```

## Free option: run it on your own Mac and share it

Netlify and Vercel run short, stateless functions and cannot host this server. The simplest free route is to run it on your own machine and share it through a Cloudflare quick tunnel (no account needed).

```
brew install cloudflared          # once, only if you want to share
bash run-on-mac.sh                # builds the jar on first run, then starts the server and the tunnel
bash run-on-mac.sh --local        # this Mac only, no tunnel
```

The script prints a local address, an access key, and (when cloudflared is installed) a public `https://....trycloudflare.com` link. Send people the link and the key. Notes:

- The key is created on first run and saved in `.access-key`, so it stays the same across restarts. The public link changes every time you restart the tunnel.
- The site is only reachable while your Mac is awake and the script is running. The script keeps the Mac from idle-sleeping, but closing the lid will still stop it.
- It uses all but one CPU core, so a big sweep will make the fans spin.
- Anyone with the link and the key can run simulations on your machine and upload `.ork` files to be parsed by it. Share the key only with people you trust, or set `ARC_ALLOW_UPLOAD=false` before running.
- A link that stays the same needs a Cloudflare account and a named tunnel on a domain you control. Quick tunnels are for sharing for a while, not for a permanent address.

## Settings

All settings are environment variables.

| Variable | Default | Meaning |
|---|---|---|
| PORT | 8080 | Port to listen on. Most hosts set this for you. |
| ARC_SIM_THREADS | CPU count | Flights run in parallel per job. Set it to the CPU share you actually have. |
| ARC_MAX_SIMS_PER_JOB | 2000 | Largest number of flights one request may ask for. |
| ARC_MAX_CONCURRENT_JOBS | 1 | Jobs running at once. Others wait in the queue. |
| ARC_QUEUE_LIMIT | 8 | Jobs allowed to wait before new ones get a 429. |
| ARC_SIM_ACCESS_KEY | unset | If set, every API call except health and config needs the header `X-Access-Key`. The browser UI prompts for it. |
| ARC_ALLOW_UPLOAD | true | Set to false to allow only the bundled demo rocket. |
| ARC_MAX_UPLOAD_MB | 5 | Largest accepted .ork upload. |
| ARC_RATE_PER_MIN | 30 | Job submissions and uploads allowed per client address per minute. |
| ARC_TRUST_PROXY | false | Set to true behind a reverse proxy so the client address comes from `X-Forwarded-For`. Leave it false if clients can reach the container directly. |
| ARC_JOB_TTL_MIN | 120 | Minutes finished jobs and uploaded rockets are kept. |
| ARC_SOURCE_URL | unset | Link shown in the page footer to your source repository. See the licence section. |

## Deploying

The image is a plain container that listens on `$PORT`, so any host that runs containers works: Fly.io, Render, Railway, Google Cloud Run, a VPS with Docker, or a Kubernetes cluster. Point the platform at this folder's Dockerfile, set the variables above, and use `/api/health` as the health check.

Sizing: a flight takes about half a second per CPU core on the 2-core machine this was built on (463 ms single-threaded measured on the desktop build). A 2000-flight job on 2 cores is therefore roughly 8 minutes. Memory is modest; 1 GB is enough for one job at a time, 2 GB leaves room for uploads. Platforms that scale to zero add a cold start of several seconds, because the engine loads its motor database on first use.

Behind a reverse proxy, forward `X-Forwarded-For`, set `ARC_TRUST_PROXY=true`, and terminate TLS there. The server speaks plain HTTP.

## Before you make it public

- Set `ARC_SIM_ACCESS_KEY` unless you want strangers burning your CPU. The rate limit and the per-job cap bound the damage but do not stop it.
- Uploaded .ork files are parsed by OpenRocket's file loader, which was written for trusted desktop use. If the site is open to anyone, set `ARC_ALLOW_UPLOAD=false`, or keep uploads behind the access key.
- Set `ARC_SOURCE_URL`. ARC-SIM is licensed AGPL-3.0, and the AGPL requires a network service to offer its users the corresponding source. The footer link satisfies that for the code in this folder, and the source for any change you make has to be reachable the same way. OpenRocket itself is GPL-3.0.
- Results live in memory and temp storage and disappear on restart. There is no database and no user accounts.

## API

All bodies are JSON unless noted. Errors come back as `{"error": "..."}` with a 4xx or 5xx status.

| Call | Purpose |
|---|---|
| GET /api/health | Liveness: `{status, version, activeJobs}` |
| GET /api/config | Limits, parameter ranges, launch sites, default targets |
| GET /api/rockets | Available rockets, with `cadAvailable` and `cadNote` |
| GET /api/rockets/{id}/mesh | Triangle mesh for the viewer. `?source=cad` (default) or `generated`. Gzip body: uint32 count, then float32 x 9 per triangle, then one class byte per triangle (0 airframe, 1 fin, 2 internal). Headers `X-Mesh-Source`, `X-Mesh-Note`. |
| POST /api/rockets | Upload a .ork file as the raw request body (header `X-Filename` optional). Validated by flying it once at standard conditions. Returns the rocket record. |
| POST /api/jobs | Start a job, returns `{id, total}` with status 202 |
| GET /api/jobs/{id} | State (`queued`, `running`, `done`, `failed`, `cancelled`), progress, ETA, and the result once done |
| DELETE /api/jobs/{id} | Cancel |
| GET /api/jobs/{id}/csv | Per-flight results |

Job request, with defaults shown where a field is optional:

```
{
  "rocket": "demo",
  "mode": "ensemble",                       // single | ensemble | sweep
  "env": {
    "windAvg": 5, "turbulencePct": 10, "temp": 15, "pressure": 1013.25, "rodAngle": 0,
    "windDirDeg": 0,
    "site": "MDRA_SOD_FARM"                 // or SPAAR_LANCASTER, or CUSTOM with lat, lon, altM
  },
  "targets": { "apogeeM": 243.84, "apogeeTolM": 0.25, "timeS": 38.5, "timeTolS": 1.0 },
  "baseSeed": 1,
  "runs": 100,                              // ensemble only
  "axes": [{"param": "windAvg", "min": 0, "max": 20, "points": 10}],   // sweep only, 1 or 2 axes
  "seedsPerPoint": 3                        // sweep only
}
```

Example:

```
curl -s -X POST localhost:8080/api/jobs -d '{"mode":"single","env":{"windAvg":5,"turbulencePct":30}}'
curl -s localhost:8080/api/jobs/<id>
```

## Things worth knowing

- The bundled demo rocket is now the ARC V2 CAD template (CSWARCMOD1E edited to the Onshape model, printed airframe weighed at 306 g). The earlier design is still listed as `mod1e`. Its still-air apogee at the MDRA site is 128 m with the 132 g ballast, well under the 243.84 m target, and pass rates read 0%. Upload a tuned design to see passes.
- The rocket view draws the CAD model when the rocket matches the template airframe and the generated mesh otherwise; the checkbox switches between them.
- Gust randomness is real. With 30% turbulence and 5 m/s wind the apogee spread is several metres (1 sd), which is wider than a 0.25 m band. A single-seed pass or fail says little; the ensemble pass rate is the number to trust.
- Wind standard deviation is not offered as an input because OpenRocket's multi-level wind model ignores it (the gust level comes from the turbulence percentage). Wind direction is accepted by the API but moves apogee by under 0.05 m.
- Launch is always into the wind with the rod tilted by the rod angle, as in the desktop app.
- Not included from the desktop app: the design solver (engine 2), weather-driven design (engine 3), the rocket builder, geometry export, Parquet output and PDF reports. The web release covers analysis of an existing design.

## Layout

```
Dockerfile, docker-compose.yml    container build and a local run recipe
run-on-mac.sh                     start on a Mac, optionally with a free public tunnel
pom.xml                           one dependency: OpenRocket core 24.12
src/main/java/com/arc/sim/        engine classes copied from the desktop project (SimRunner, WindSeeder, ...)
src/main/java/com/arc/sim/web/    HTTP server, job queue, request validation, statistics
src/main/resources/web/           browser UI (plain HTML, CSS and JavaScript, no external requests)
src/main/resources/rockets/       demo.ork
src/test/                         end-to-end API tests that fly real simulations
```
