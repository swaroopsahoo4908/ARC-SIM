import numpy as np, json, gzip, struct, os
OUT='/home/claude/cadwork/out'; os.makedirs(OUT+'/cad',exist_ok=True)
RHO=1.24e-3  # g/mm3, Bambu Lab PLA Basic, ISO 1183 (TDS V2.0)
L=735.0
OFF={'nose_cone':583.0,'upper':420.0,'mid':195.0,'lower_body':0.0,'motor_mount':0.0,'retainer_cap':0.0,'fin_1':0.0}
parts=json.load(open('/tmp/cadout/parts.json'))

def write(name,V,T):
    V=V.astype('<f4'); T=T.astype('<i4')
    with gzip.open(f'{OUT}/cad/{name}.arcmesh','wb',9) as f:
        f.write(struct.pack('<4sii',b'ARCM',len(V),len(T))); f.write(V.tobytes()); f.write(T.tobytes())

def rocket_frame(n):
    V=np.load(f'/tmp/cadout/{n}_V.npy'); T=np.load(f'/tmp/cadout/{n}_T.npy')
    R=np.stack([L-(OFF[n]+V[:,1]), -V[:,0], -V[:,2]],axis=1)   # proper rotation (det=+1): winding preserved
    return R,T
for n,o in [('nose_cone','nose'),('upper','upper'),('mid','mid'),('lower_body','lower'),('motor_mount','motor_mount'),('retainer_cap','retainer')]:
    R,T=rocket_frame(n); write(o,R,T)
# fin: fin-local frame (axial from nose tip, radial rho, thickness t)
V=np.load('/tmp/cadout/fin_1_V.npy'); T=np.load('/tmp/cadout/fin_1_T.npy')
write('fin',np.stack([L-V[:,1],V[:,0],V[:,2]],axis=1),T)

def xcg(n,y): return L-(OFF[n]+y)   # abs x from nose tip (mm)
p=parts
nose=dict(vol=p['nose_cone']['vol'],x=xcg('nose_cone',p['nose_cone']['com'][1]))
upper=dict(vol=p['upper']['vol'],x=xcg('upper',p['upper']['com'][1]))
trans=dict(vol=p['mid_transition']['vol'],x=xcg('mid',p['mid_transition']['cy']))
ms=dict(vol=p['mid_straight']['vol'],x=xcg('mid',p['mid_straight']['cy']))
low=dict(vol=p['lower_body']['vol'],x=xcg('lower_body',p['lower_body']['com'][1]))
mm=dict(vol=p['motor_mount']['vol'],x=xcg('motor_mount',p['motor_mount']['com'][1]))
rc=dict(vol=p['retainer_cap']['vol'],x=xcg('retainer_cap',p['retainer_cap']['com'][1]))
fin=dict(vol=4*p['fin_1']['vol'],x=xcg('fin_1',p['fin_1']['com'][1]))
def comb(*a):
    v=sum(q['vol'] for q in a); return dict(vol=v,x=sum(q['vol']*q['x'] for q in a)/v)
lower_tube=comb(low,ms); eng=comb(mm,rc)
def row(id,name,comp,q,note):
    return dict(id=id,name=name,orComponent=comp,volumeMm3=round(q['vol'],1),massG=round(q['vol']*RHO,2),cgFromNoseTipMm=round(q['x'],2),note=note)
rows=[row('nose','Nose cone','NoseCone',nose,'ellipsoid, 152 mm, base r 27.0 mm'),
 row('upper','Upper airframe (incl. bulkhead ring and spigots)','BodyTube "Upper"',upper,'r 27.0 mm, 163 mm exposed, 0.85 mm wall'),
 row('transition','Mid section, transition half','Transition',trans,'115 mm, r 27.0 -> 33.0 mm'),
 row('lower','Lower airframe + mid straight half (rail buttons included)','BodyTube "Lower"',lower_tube,'r 33.0 mm, 305 mm'),
 row('fins','Fins x4 (airfoil, 2.4 mm)','TrapezoidFinSet',fin,'root 130 / tip 55.2 / sweep 55 / height 70 mm'),
 row('motor_mount','Motor mount + retainer cap','InnerTube "Engine Mount"',eng,'29.5 mm bore, 118.75 mm, aft end 12 mm behind the airframe')]
tot=sum(r['massG'] for r in rows)
doc=dict(source='ARC_V2_1.zip (Onshape, STEP AP242, millimetres)',
  material=dict(name='Bambu Lab PLA Basic',densityGcm3=1.24,reference='Bambu Lab, PLA Basic Technical Data Sheet V2.0, ISO 1183'),
  assumption='Each part is printed solid as modelled (the CAD already contains the real 0.85-2.8 mm walls), so mass = CAD volume x density. No slicer infill, supports, glue or paint included.',
  totalLengthMm=L, printedMassG=round(tot,2),
  nose=dict(lengthMm=152.0,baseRadiusMm=27.0,thicknessMm=1.85,shape='ellipsoid'),
  upper=dict(lengthMm=163.0,radiusMm=27.0,thicknessMm=0.85),
  transition=dict(lengthMm=115.0,foreRadiusMm=27.0,aftRadiusMm=33.0,thicknessMm=0.85),
  lower=dict(lengthMm=305.0,radiusMm=33.0,thicknessMm=1.26),
  fin=dict(count=4,rootChordMm=130.0,tipChordMm=55.2,sweepMm=55.0,heightMm=70.0,thicknessMm=2.4,azimuthsDeg=[45,135,225,315]),
  motorMount=dict(outerRadiusMm=16.43,boreRadiusMm=14.75,lengthMm=118.75,aftOffsetMm=-12.0,motorOverhangMm=10.5),
  railButtons=dict(centersFromAftMm=[37.5,172.5],lengthMm=25.0,protrusionMm=6.44,azimuthDeg=0),
  parts=rows)
json.dump(doc,open(OUT+'/arc_v2_parts.json','w'),indent=1)
for r in rows: print(f"{r['id']:12s} vol={r['volumeMm3']:9.1f} mm3  m={r['massG']:7.2f} g  cg x={r['cgFromNoseTipMm']:7.2f} mm")
print('total printed mass',round(tot,2),'g')
os.system(f'ls -l {OUT}/cad | tail -8; du -sh {OUT}/cad')
