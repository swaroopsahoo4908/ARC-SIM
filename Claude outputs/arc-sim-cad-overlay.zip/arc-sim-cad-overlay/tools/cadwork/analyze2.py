import numpy as np, json, glob, os
from OCP.STEPControl import STEPControl_Reader
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.gp import gp_Pnt

def load(n):
    r=STEPControl_Reader(); r.ReadFile(f'/tmp/arcv2/ARC_V2 - {n}.step'); r.TransferRoots(); return r.OneShape()
def props(s):
    p=GProp_GProps(); BRepGProp.VolumeProperties_s(s,p); c=p.CentreOfMass(); return p.Mass(), (c.X(),c.Y(),c.Z())

def slice_r(n,h):
    V=np.load(f'/tmp/cadout/{n}_V.npy'); T=np.load(f'/tmp/cadout/{n}_T.npy'); out=[]
    for a,b,c in T:
        P=[V[a],V[b],V[c]]
        for i in range(3):
            p,q=P[i],P[(i+1)%3]
            if (p[1]-h)*(q[1]-h)<0:
                t=(h-p[1])/(q[1]-p[1]); pt=p+t*(q-p); out.append(np.hypot(pt[0],pt[2]))
    out=np.array(out); return (np.unique(np.round(out,2)) if len(out) else out)

res={}
print('slice radii (mm)')
for n,hs in [('upper',[40,100,150]),('mid',[60,150,200]),('lower_body',[60,120,170]),('nose_cone',[10,60]),('motor_mount',[40,80])]:
    for h in hs:
        r=slice_r(n,h); print(f'  {n:12s} y={h:4d}:',r[:2],'..',r[-2:] if len(r) else '')

# mid split at y=110
mid=load('mid')
def part(shape,y0,y1):
    box=BRepPrimAPI_MakeBox(gp_Pnt(-100,y0,-100),gp_Pnt(100,y1,100)).Shape()
    c=BRepAlgoAPI_Common(shape,box).Shape(); return props(c)
vS,cS=part(mid,-1,110); vT,cT=part(mid,110,300)
print('mid straight v=%.1f mm3 cy=%.2f | mid transition v=%.1f cy=%.2f'%(vS,cS[1],vT,cT[1]))
res['mid_straight']=dict(vol=vS,cy=cS[1]); res['mid_transition']=dict(vol=vT,cy=cT[1])

# rail button extents in lower_body (x<-33.3)
V=np.load('/tmp/cadout/lower_body_V.npy'); m=V[:,0]<-33.3
ys=np.sort(V[m,1]); gaps=np.where(np.diff(ys)>5)[0]
groups=np.split(ys,gaps+1); print('rail button y-extents:',[(round(g.min(),1),round(g.max(),1)) for g in groups])
print('rail max protrusion r:',np.hypot(V[m,0],V[m,2]).max())

# fin & per-part centroid/volume
for n in ['nose_cone','upper','mid','lower_body','motor_mount','retainer_cap','fin_1']:
    v,c=props(load(n)); res[n]=dict(vol=v,com=c); print(f'{n:12s} vol={v:10.1f} mm3 com y={c[1]:.2f} x={c[0]:.2f} z={c[2]:.2f}')
json.dump(res,open('/tmp/cadout/parts.json','w'),indent=1)
