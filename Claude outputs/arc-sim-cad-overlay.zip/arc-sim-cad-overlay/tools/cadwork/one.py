import sys,time
from OCP.STEPControl import STEPControl_Reader
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE, TopAbs_SOLID, TopAbs_SHELL, TopAbs_COMPOUND
f=sys.argv[1]
r=STEPControl_Reader(); r.ReadFile(f); print('nroots',r.NbRootsForTransfer(),flush=True); r.TransferRoots(); s=r.OneShape()
def cnt(t):
    e=TopExp_Explorer(s,t); n=0
    while e.More(): n+=1; e.Next()
    return n
print('solids',cnt(TopAbs_SOLID),'faces',cnt(TopAbs_FACE),flush=True)
t=time.time(); p=GProp_GProps(); BRepGProp.VolumeProperties_s(s,p); print('vol mm3',p.Mass(),time.time()-t,flush=True)
t=time.time(); BRepMesh_IncrementalMesh(s,float(sys.argv[2]),False,float(sys.argv[3]),False); print('meshed',time.time()-t,flush=True)
