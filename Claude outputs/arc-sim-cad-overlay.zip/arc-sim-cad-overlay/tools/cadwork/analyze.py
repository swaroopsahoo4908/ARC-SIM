import sys, glob, json, math, struct, os
import numpy as np
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRep import BRep_Tool
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE, TopAbs_REVERSED
from OCP.TopoDS import TopoDS
from OCP.TopLoc import TopLoc_Location

src, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
res = {}
for f in sorted(glob.glob(src + '/*.step')):
    name = os.path.basename(f).replace('ARC_V2 - ', '').replace('.step', '')
    r = STEPControl_Reader()
    assert r.ReadFile(f) == IFSelect_RetDone
    r.TransferRoots()
    shp = r.OneShape()
    p = GProp_GProps(); BRepGProp.VolumeProperties_s(shp, p)
    vol = p.Mass(); com = p.CentreOfMass()
    b = Bnd_Box(); BRepBndLib.AddOptimal_s(shp, b, True, False)
    x0, y0, z0, x1, y1, z1 = b.CornerMin().X(), b.CornerMin().Y(), b.CornerMin().Z(), b.CornerMax().X(), b.CornerMax().Y(), b.CornerMax().Z()
    BRepMesh_IncrementalMesh(shp, 0.06, False, 0.22, False)
    V, T = [], []
    ex = TopExp_Explorer(shp, TopAbs_FACE)
    while ex.More():
        face = TopoDS.Face(ex.Current())
        loc = TopLoc_Location()
        tri = BRep_Tool.Triangulation_s(face, loc)
        if tri is not None:
            tr = loc.Transformation()
            base = len(V)
            for i in range(1, tri.NbNodes() + 1):
                q = tri.Node(i).Transformed(tr); V.append((q.X(), q.Y(), q.Z()))
            rev = face.Orientation() == TopAbs_REVERSED
            for i in range(1, tri.NbTriangles() + 1):
                a, bb, c = tri.Triangle(i).Get()
                a, bb, c = a - 1 + base, bb - 1 + base, c - 1 + base
                T.append((a, c, bb) if rev else (a, bb, c))
        ex.Next()
    V = np.array(V); T = np.array(T)
    np.save(f'{out}/{name}_V.npy', V); np.save(f'{out}/{name}_T.npy', T)
    # mesh volume cross-check
    A, B, C = V[T[:, 0]], V[T[:, 1]], V[T[:, 2]]
    mvol = np.einsum('ij,ij->i', A, np.cross(B, C)).sum() / 6.0
    res[name] = dict(volume_m3=vol, mesh_volume_m3=mvol, com=[com.X(), com.Y(), com.Z()],
                     bbox=[x0, y0, z0, x1, y1, z1], tris=len(T))
    print(f"{name:14s} vol={vol*1e6:9.3f} cm3 meshvol={mvol*1e6:9.3f} com=({com.X():.4f},{com.Y():.4f},{com.Z():.4f}) "
          f"bbox y[{y0:.4f},{y1:.4f}] x[{x0:.4f},{x1:.4f}] z[{z0:.4f},{z1:.4f}] tris={len(T)}")
json.dump(res, open(out + '/summary.json', 'w'), indent=1)
